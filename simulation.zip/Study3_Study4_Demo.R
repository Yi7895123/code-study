# Demo: Studies 3-4 use the same estimation routines and different DGPs.
# Reference experiment confirmed by the authors and the Example 5.1 run label:
# Study 3, Case 1; N=10, T=10, R=200, seedMC=66.
# Proposed h: 0.10-0.30 by 0.05; Chen (2013a) h: 0.25-0.45 by 0.05.
STUDY <- 3L
CASE <- 1L
N <- 10L
T <- 10L
D <- 1L
REPLICATIONS <- 200L
SEED_BASE <- 66L
H_PROPOSED <- seq(0.10, 0.30, by = 0.05)
H_BENCHMARK <- seq(0.25, 0.45, by = 0.05)  # Mth3 (Chen 2013a)
LAMBDA <- NULL

# When using another study/case or N,T, supply its appropriate seed/grid.
# ============================================================
# Locate the directory containing this script
# ============================================================

root_flags <- grep(
  "^--file=",
  commandArgs(trailingOnly = FALSE),
  value = TRUE
)

root <- if (length(root_flags)) {

  dirname(
    normalizePath(
      sub("^--file=", "", root_flags[1])
    )
  )

} else {

  of <- vapply(
    sys.frames(),
    function(f) {
      if (is.null(f$ofile)) {
        ""
      } else {
        as.character(f$ofile)
      }
    },
    character(1)
  )

  of <- of[nzchar(of)]

  if (length(of)) {
    dirname(normalizePath(tail(of, 1)))
  } else {
    normalizePath(getwd())
  }
}
source(file.path(root,'R','demo_engine.R'))
demo_load(root)
stopifnot(STUDY %in% c(3L,4L),CASE %in% c(1L,2L))
if(STUDY==3L) D <- if(CASE==1L) 1L else 2L
if(STUDY==4L && is.null(LAMBDA)) LAMBDA <- if(CASE==1L) 0.5 else 0.25
suffix <- if(STUDY==4L) paste0('_lambda_',LAMBDA) else ''
demo_run_comparison(STUDY,CASE,N,T,D,REPLICATIONS,SEED_BASE,
  H_PROPOSED,H_BENCHMARK,
  output=file.path(root,'results',paste0(sprintf('Study%d_Case%d',STUDY,CASE),suffix)),
  lambda=LAMBDA)
