# Study 5: Case 1 intentionally reallocates Z to X; Case 2 compares
# ADE initial, one-step and final estimates; Case 3 performs inference.
# Every replication uses its own CV-optimal bandwidth.
CASE <- 1L
# ============================================================
# Locate the directory containing this script
# ============================================================

root_flags <- grep(
  "^--file=",
  commandArgs(trailingOnly = FALSE),
  value = TRUE
)

root <- if (length(root_flags)) {

  dirname(
    normalizePath(
      sub("^--file=", "", root_flags[1])
    )
  )

} else {

  of <- vapply(
    sys.frames(),
    function(f) {
      if (is.null(f$ofile)) {
        ""
      } else {
        as.character(f$ofile)
      }
    },
    character(1)
  )

  of <- of[nzchar(of)]

  if (length(of)) {
    dirname(normalizePath(tail(of, 1)))
  } else {
    normalizePath(getwd())
  }
}
source(file.path(root,'R','demo_engine.R'))
demo_load(root,study5=TRUE)
if(CASE==1L) {
  # Reference design: N=10, T=30, k=1, continuous original Z variables.
  # Author-confirmed seed base and Mth1 CV grid. 200 reps are retained from
  # the previous source-results archive; each r has seed SEED_BASE+r.
  N<-10L;T<-30L;REPLICATIONS<-200L;SEED_BASE<-10000L
  SEED_Z_SELECTION<-31001L;NUMBER_MOVED_Z<-1L
  H_PROPOSED<-seq(0.15,0.45,by=0.05)
  demo_run_misallocation(N,T,REPLICATIONS,SEED_BASE,
       SEED_Z_SELECTION,NUMBER_MOVED_Z,H_PROPOSED,
       file.path(root,'results','Study5_Case1'))
} else if (CASE==2L) {
  # Illustrative three-stage analysis using the Study 1 Case 1 reference DGP.
  # NOT independently verified as the historical Study 5 Case 2 schedule.
  N<-5L;T<-20L;REPLICATIONS<-200L;SEED_BASE<-15L
  H_PROPOSED<-seq(0.10,0.35,by=0.05)
  demo_run_stage_comparison(N,T,REPLICATIONS,SEED_BASE,H_PROPOSED,
       file.path(root,'results','Study5_Case2'))
} else if (CASE==3L) {
  # Demonstration of pointwise inference on the reference Study 1 DGP.
  # These are IID plug-in intervals, not generic serial-correlation-robust HAC.
  N<-5L;T<-20L;REPLICATIONS<-200L;SEED_BASE<-15L
  H_PROPOSED<-seq(0.10,0.35,by=0.05)
  demo_run_inference(N,T,REPLICATIONS,SEED_BASE,H_PROPOSED,
       file.path(root,'results','Study5_Case3'),
       ci_level=0.95,grid_n=41L,bias_mult=1.5,trim=0.10)
} else stop('CASE must be 1, 2, or 3.')
