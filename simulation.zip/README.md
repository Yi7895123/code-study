# Demo Code for Monte Carlo Simulations

**Paper:** *A Partially Linear Single-Index Panel Data Model with Individual-Specific Link Functions*

This compact package demonstrates the simulation data-generating processes, the
proposed estimator (Mth1), its benchmark estimators (Mth2 and Mth3), ADE-type
initialisation, per-replication cross-validation, marginal-effect evaluation,
and the three Study 5 calculations. 
## 1. Files

| File | Purpose |
|---|---|
| `Study1_Study2_Demo.R` | Study 1 Case 1 reference run; shared method for Study 1 and Study 2 variants (Mth1 versus Mth2). |
| `Study3_Study4_Demo.R` | Study 3 Case 1 reference run; shared method for Study 3 and Study 4 variants (Mth1 versus Mth3). |
| `Study5_Demo.R` | Case 1: covariate reallocation; Case 2: initial/one-step/final efficiency; Case 3: coefficient and link-function confidence intervals. |
| `R/estimators.R` | Shared Mth1/Mth2/Mth3 estimation, ADE-type initialisation and CV functions. |
| `R/dgp.R` | Data generators and individual-specific link functions. |
| `R/demo_engine.R` | Replication loop, method-specific CV, estimation and CSV summaries. |
| `R/misallocation.R` | Covariate-reallocation evaluation routines. |
| `R/inference.R` | Confidence-interval calculations for Study 5 Case 3. |
| `SOURCE_NOTES.md` | Provenance and limitations of the reference settings. |



## 2. Running the demonstrations

Install R and the recommended R package `MASS`. Extract the archive and, in
its top-level folder, run:

```sh
Rscript Study1_Study2_Demo.R
Rscript Study3_Study4_Demo.R
Rscript Study5_Demo.R
```

The default `CASE` in `Study5_Demo.R` is `1L`. Change it to `2L` or `3L` to
run the other two experiments. Open the scripts in RStudio and use **Source**
if preferred. The default 200-replication experiments can be computationally
intensive; for a quick functionality check temporarily reduce `REPLICATIONS`,
without changing the candidate grids.

## 3. Bandwidth selection

For Monte Carlo repetition `r`, the driver uses `set.seed(SEED_BASE+r)` and
simulates a single panel. Each estimated method independently computes its CV
scores over the declared candidate bandwidths on that panel, selects the
minimum-CV bandwidth, and refits on **the same panel**. Formally,

`h_(r,m) = argmin_{h in H_m} CV_m(D_r, h)`.

## 4. Results and restrictions

The scripts generate only these result files under `results/Study*_Case*/`:

- `replications.csv`: one or more rows per replication, including the selected
  bandwidth (`selected_h`) and its minimum CV score (`cv_mse`).
- `summary.csv`: averages and the relevant study-level evaluation metrics.

**No Excel (`.xls`/`.xlsx`) files are included or generated.** Results are
written as ordinary UTF-8-compatible CSV files by base R.


