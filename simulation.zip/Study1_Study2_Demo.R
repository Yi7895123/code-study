# Demo: Studies 1-2 share the estimators but differ in their data generators.
# Reference experiment confirmed by the authors: Study 1, Case 1.
# All CV bandwidths are selected independently for each Monte Carlo replication.
STUDY <- 1L
CASE <- 1L
N <- 5L
T <- 20L
D <- 1L
REPLICATIONS <- 200L
SEED_BASE <- 15L
H_PROPOSED <- seq(0.10, 0.35, by = 0.05)
H_BENCHMARK <- seq(0.80, 0.90, by = 0.05)  # Mth2

# For another Study/Case or another N,T, adjust the generator and use the
# appropriate documented seed and two CV candidate grids.
# ============================================================
# Locate the directory containing this script
# ============================================================

root_flags <- grep(
  "^--file=",
  commandArgs(trailingOnly = FALSE),
  value = TRUE
)

root <- if (length(root_flags)) {

  dirname(
    normalizePath(
      sub("^--file=", "", root_flags[1])
    )
  )

} else {

  of <- vapply(
    sys.frames(),
    function(f) {
      if (is.null(f$ofile)) {
        ""
      } else {
        as.character(f$ofile)
      }
    },
    character(1)
  )

  of <- of[nzchar(of)]

  if (length(of)) {
    dirname(normalizePath(tail(of, 1)))
  } else {
    normalizePath(getwd())
  }
}
source(file.path(root,'R','demo_engine.R'))
demo_load(root)
stopifnot(STUDY %in% c(1L,2L),CASE %in% c(1L,2L))
demo_run_comparison(STUDY,CASE,N,T,D,REPLICATIONS,SEED_BASE,
   H_PROPOSED,H_BENCHMARK,
   output=file.path(root,'results',sprintf('Study%d_Case%d',STUDY,CASE)))
