# Shared demonstration workflow. Original numerical estimator functions are
# sourced unchanged from estimators.R. There is no fixed-bandwidth branch.
# Every replicate r gets one newly generated panel and its OWN CV-optimal h.

demo_locate_root <- function() {
  flags <- grep('^--file=', commandArgs(trailingOnly=FALSE), value=TRUE)
  if (length(flags))
    return(dirname(normalizePath(sub('^--file=', '', flags[1]))))
  frames <- vapply(sys.frames(), function(e)
    if (!is.null(e$ofile)) as.character(e$ofile) else '', character(1))
  frames <- frames[nzchar(frames)]
  if (length(frames)) return(dirname(normalizePath(tail(frames,1))))
  normalizePath(getwd())
}

demo_load <- function(root, study5 = FALSE) {
  if (!requireNamespace('MASS', quietly=TRUE))
    stop('R package MASS is required for the original pseudoinverse algorithm.')
  source(file.path(root,'R','estimators.R'), local=.GlobalEnv)
  source(file.path(root,'R','dgp.R'), local=.GlobalEnv)
  if (study5) {
    source(file.path(root,'R','inference.R'), local=.GlobalEnv)
    source(file.path(root,'R','misallocation.R'), local=.GlobalEnv)
  }
  invisible(TRUE)
}

# These preserve the active methods and cross-validation calls from the unified
# archive. Mth1/Mth2 CV leave out a time point; Mth3 CV leaves out an individual.
demo_choose_bandwidth <- function(X, Z, Y, candidates, method,
                                  cv_tol=1e-4, cv_maxit=30L,
                                  chen_init_iter=50L, chen_tol=1e-5,
                                  chen_maxit=100L) {
  if (!is.numeric(candidates) || length(unique(candidates))<2L ||
      any(!is.finite(candidates)) || any(candidates<=0))
    stop('At least two distinct finite positive CV bandwidth candidates required.')
  cv <- switch(method,
    Mth1=cv_curve_method1(X,Z,Y,candidates,toler=cv_tol,maxit=cv_maxit),
    Mth2=cv_curve_method2(X,Z,Y,candidates,toler=cv_tol,maxit=cv_maxit),
    Mth3=cv_curve_chen2013a_authors_code(X,Z,Y,candidates,
       init_iter=chen_init_iter,toler=chen_tol,maxit=chen_maxit),
    stop('Unknown comparison method: ',method))
  if(length(cv)!=length(candidates) || !any(is.finite(cv)))
    stop('Cross validation did not return a finite score for ',method)
  i <- which.min(replace(cv,!is.finite(cv),Inf))
  list(h=candidates[i],cv_mse=cv[i],boundary=i %in% c(1L,length(candidates)))
}


# Batch schedules are used only when actual archived runs show different seeds
# or candidate grids for different replication blocks. Each replication still
# independently computes and minimises its own CV curve.
demo_rep_settings <- function(r,batches=NULL,seed_base=NULL,h1=NULL,h_other=NULL) {
  if(is.null(batches)) return(list(seed=seed_base+r,h1=h1,h_other=h_other))
  j <- r
  for(b in batches) {
    if(j<=b$R) return(list(seed=b$seed_base+j,h1=b$h1,h_other=b$h_other))
    j <- j-b$R
  }
  stop("Requested replication is beyond archived batch definition")
}

demo_fit_proposed <- function(dat, h, tol=1e-6, maxit=300L) {
  initial <- init_method1(dat$X,dat$Z,dat$Y)
  fit_method1(dat$X,dat$Z,dat$Y,h,
     theta_init=initial$theta,beta_init=initial$beta,
     toler=tol,maxit=maxit)
}

demo_fit_benchmark <- function(dat, h, method, tol=1e-6, maxit=300L,
                               chen_init_iter=50L,chen_tol=1e-5,
                               chen_maxit=100L) {
  if(method=='Mth2') {
    initial <- init_method2(dat$X,dat$Z,dat$Y)
    return(fit_method2(dat$X,dat$Z,dat$Y,h,
         theta_init=initial$theta_all,toler=tol,maxit=maxit))
  }
  if(method=='Mth3')
    return(fit_chen2013a_authors_code(dat$X,dat$Z,dat$Y,h,
       init_iter=chen_init_iter,toler=chen_tol,maxit=chen_maxit))
  stop('Unknown benchmark ',method)
}

demo_get_data <- function(study, case, N, T, beta, lambda=NULL) {
  theta <- if(study==3L && case==2L) c(2,1,2)/3 else c(1,1,1)/sqrt(3)
  dat <- if(study %in% c(1L,2L))
           generate_study12(N,T,theta,beta,study,case)
         else if(study==3L && case==1L)
           generate_study3_case1(N,T,theta,beta)
         else if(study==3L && case==2L)
           generate_study3_case2(N,T,theta,beta)
         else if(study==4L && case==1L)
           generate_study4_case1(N,T,theta,beta,lambda)
         else if(study==4L && case==2L)
           generate_study4_case2(N,T,theta,beta,lambda)
         else stop('Unsupported study/case')
  list(dat=dat,theta=theta)
}

demo_beta_true <- function(study,case,d) {
  if(study==3L && case==1L) return(0.3)
  if(study==3L && case==2L) return(c(2,1)/sqrt(5))
  rep(c(1,-1,0.5,0.7,-0.5),length.out=d)
}

demo_vector_string <- function(x) paste(format(as.numeric(x),digits=9),collapse=';')

demo_save_two_tables <- function(rows, path, group='method') {
  dir.create(path,recursive=TRUE,showWarnings=FALSE)
  tab <- do.call(rbind,rows)
  rownames(tab)<-NULL
  utils::write.csv(tab,file.path(path,'replications.csv'),row.names=FALSE)
  means <- split(tab, tab[[group]])
  summary <- do.call(rbind,lapply(means,function(z) {
    data.frame(method=z[[group]][1],replications=nrow(z),
       mean_selected_h=mean(z$selected_h),
       mean_cv_mse=mean(z$cv_mse),
       mean_coef_mse=if(all(is.na(z$coef_mse))) NA_real_ else mean(z$coef_mse,na.rm=TRUE),
       mean_effect_mse=mean(z$effect_mse),
       mean_signal_mse=mean(z$signal_mse),
       mean_fit_mse=mean(z$fit_mse))
  }))
  rownames(summary)<-NULL
  utils::write.csv(summary,file.path(path,'summary.csv'),row.names=FALSE)
  invisible(summary)
}

# One complete demonstration of comparison methods. Only TWO CSVs are written.
demo_run_comparison <- function(study,case,N,T,d,replications,seed_base,
                                proposed_grid,benchmark_grid,output,lambda=NULL,
                                cv_tol=1e-4,cv_maxit=30L,
                                fit_tol=1e-6,fit_maxit=300L,
                                chen_init_iter=50L,chen_tol=1e-5,
                                chen_maxit=100L,batches=NULL) {
  stopifnot(replications>=1L,N>=2L,T>=3L)
  method <- if (study %in% c(1L,2L)) 'Mth2' else 'Mth3'
  beta <- demo_beta_true(study,case,d)
  rows<-vector('list',2L*replications)
  for(r in seq_len(replications)) {
    spec <- demo_rep_settings(r,batches,seed_base,proposed_grid,benchmark_grid)
    set.seed(spec$seed)
    generated<-demo_get_data(study,case,N,T,beta,lambda)
    dat<-generated$dat;theta<-generated$theta
    # Both methods see this SAME generated panel, but choose h independently.
    h1<-demo_choose_bandwidth(dat$X,dat$Z,dat$Y,spec$h1,'Mth1',
                              cv_tol=cv_tol,cv_maxit=cv_maxit)
    ho<-demo_choose_bandwidth(dat$X,dat$Z,dat$Y,spec$h_other,method,
                              cv_tol=cv_tol,cv_maxit=cv_maxit,
                              chen_init_iter=chen_init_iter,chen_tol=chen_tol,
                              chen_maxit=chen_maxit)
    f1<-demo_fit_proposed(dat,h1$h,fit_tol,fit_maxit)
    fo<-demo_fit_benchmark(dat,ho$h,method,fit_tol,fit_maxit,
                           chen_init_iter,chen_tol,chen_maxit)
    eff<-if(method=='Mth2')
      evaluate_effects_two_methods(dat,f1,fo,theta,beta,h1$h,ho$h)
    else evaluate_effects_prop_chen_unified(dat,f1,fo,theta,beta)
    m1<-mean(eff$point_mse[eff$method=='Mth1_proposed'])
    mb<-mean(eff$point_mse[eff$method!= 'Mth1_proposed'])
    pred1<-f1$a+z_linear_part(dat$Z,f1$beta)
    predb<-if(method=='Mth2') fo$a_all else
      fo$a+z_linear_part(dat$Z,fo$beta)+matrix(fo$alpha,nrow(dat$Y),ncol(dat$Y))
    sig<-dat$Y-dat$e
    coef1<-mean((c(f1$theta,f1$beta)-c(theta,beta))^2)
    coefb<-if(method=='Mth3')
       mean((c(fo$theta,fo$beta)-c(theta,beta))^2) else NA_real_
    rows[[2L*r-1L]]<-data.frame(
       rep=r,seed=spec$seed,method='Mth1_proposed',N=N,T=T,d=d,
       selected_h=h1$h,cv_mse=h1$cv_mse,grid_boundary=h1$boundary,
       theta_est=demo_vector_string(f1$theta),beta_est=demo_vector_string(f1$beta),
       coef_mse=coef1,effect_mse=m1,
       signal_mse=mean((pred1-sig)^2),fit_mse=mean((pred1-dat$Y)^2),
       iterations=f1$iter)
    rows[[2L*r]]<-data.frame(
       rep=r,seed=spec$seed,method=if(method=='Mth2') 'Mth2_Chen2013b' else 'Mth3_Chen2013a',
       N=N,T=T,d=d,selected_h=ho$h,cv_mse=ho$cv_mse,grid_boundary=ho$boundary,
       theta_est=demo_vector_string(if(method=='Mth2') fo$theta_all else fo$theta),
       beta_est=if(method=='Mth2') '' else demo_vector_string(fo$beta),
       coef_mse=coefb,effect_mse=mb,
       signal_mse=mean((predb-sig)^2),fit_mse=mean((predb-dat$Y)^2),
       iterations=fo$iter)
    cat(sprintf('Study %d Case %d rep %d/%d: Mth1 h=%.3g, %s h=%.3g\n',
                study,case,r,replications,h1$h,method,ho$h))
  }
  demo_save_two_tables(rows,output)
}

demo_run_stage_comparison <- function(N,T,replications,seed_base,h_grid,output,
                                      cv_tol=1e-4,cv_maxit=30L,
                                      fit_tol=1e-6,fit_maxit=300L,batches=NULL) {
  theta <- c(1,1,1)/sqrt(3); beta <- 1
  rows <- vector('list',replications)
  for(r in seq_len(replications)) {
    spec <- demo_rep_settings(r,batches,seed_base,h_grid)
    set.seed(spec$seed)
    dat <- generate_study12(N,T,theta,beta,1L,1L)
    h <- demo_choose_bandwidth(dat$X,dat$Z,dat$Y,spec$h1,'Mth1',cv_tol,cv_maxit)
    f <- demo_fit_proposed(dat,h$h,fit_tol,fit_maxit)
    stages<-list(initial=c(f$init_theta,f$init_beta),
                 one_step=c(f$one_theta,f$one_beta),
                 converged=c(f$theta,f$beta))
    rows[[r]]<-do.call(rbind,lapply(names(stages),function(stage) {
      v<-stages[[stage]];truth<-c(theta,beta)
      data.frame(rep=r,seed=spec$seed,stage=stage,
         selected_h=h$h,cv_mse=h$cv_mse,
         theta_est=demo_vector_string(v[1:3]),beta_est=v[4],
         coef_mse=mean((v-truth)^2),iteration_count=f$iter)
    }))
    cat(sprintf('Study 5 Case 2 rep %d/%d: selected h=%.4g\n',r,replications,h$h))
  }
  dir.create(output,recursive=TRUE,showWarnings=FALSE)
  tab<-do.call(rbind,rows)
  utils::write.csv(tab,file.path(output,'replications.csv'),row.names=FALSE)
  ss<-do.call(rbind,lapply(split(tab,tab$stage),function(z)
    data.frame(stage=z$stage[1],replications=nrow(z),
               mean_coef_mse=mean(z$coef_mse),
               NT_scaled_mse=N*T*mean(z$coef_mse),
               mean_selected_h=mean(z$selected_h))))
  utils::write.csv(ss,file.path(output,'summary.csv'),row.names=FALSE)
  invisible(ss)
}

demo_run_inference <- function(N,T,replications,seed_base,h_grid,output,
                               ci_level=0.95,grid_n=41L,bias_mult=1.5,trim=0.10,
                               cv_tol=1e-4,cv_maxit=30L,
                               fit_tol=1e-6,fit_maxit=300L,batches=NULL) {
  theta <- c(1,1,1)/sqrt(3);beta <- 1
  grid<-ci_make_grid(theta,grid_n);constants<-ci_kernel_constants()
  rows<-vector('list',replications)
  for(r in seq_len(replications)) {
    spec<-demo_rep_settings(r,batches,seed_base,h_grid)
    set.seed(spec$seed)
    dat<-generate_study12(N,T,theta,beta,1L,1L)
    dat$gpp_list<-lapply(seq_len(N),function(i) ci_get_g(i)$gpp)
    dat$g_id<-((seq_len(N)-1L)%%15L)+1L
    h<-demo_choose_bandwidth(dat$X,dat$Z,dat$Y,spec$h1,'Mth1',cv_tol,cv_maxit)
    f<-demo_fit_proposed(dat,h$h,fit_tol,fit_maxit)
    coef<-tryCatch({
      nuisance<-ci_nuisance(dat$X,dat$Z,dat$Y,f,ci_kernel,safe_ginv)
      ci_parameters(dat$X,dat$Z,dat$Y,f,nuisance,ci_level)$rows
    }, error=function(e) {
      warning('Coefficient interval unavailable for rep ',r,': ',conditionMessage(e))
      data.frame(parameter=c('theta1','theta2','theta3','beta1'),
         estimate=c(f$theta,f$beta),se=NA_real_,lower=NA_real_,upper=NA_real_,valid=FALSE)
    })
    truth<-c(theta,beta)
    ccover<-ifelse(coef$valid & is.finite(coef$lower) & is.finite(coef$upper),
                   coef$lower<=truth & truth<=coef$upper,NA)
    coef_rows<-data.frame(rep=r,seed=spec$seed,target=coef$parameter,
       interval='coefficient_Wald',region='all',covered=ccover,
       width=coef$upper-coef$lower,selected_h=h$h,cv_mse=h$cv_mse)
    link_rows<-do.call(rbind,lapply(seq_len(N),function(i) {
      z<-ci_eval_station(dat,f,i,theta,h$h,grid,constants,
         bias_bw_mult=bias_mult,ci_level=ci_level,
         interior_trim=trim,primary_se='equivalent')
      do.call(rbind,lapply(c('raw','oracle','feasible'),function(kind)
        data.frame(rep=r,seed=spec$seed,target=paste0('link_station',i),
          interval=paste0('link_',kind),region=z$region,
          covered=z[[paste0('covered_',kind)]],width=z$width,
          selected_h=h$h,cv_mse=h$cv_mse)))
    }))
    rows[[r]]<-rbind(coef_rows,link_rows)
    cat(sprintf('Study 5 Case 3 rep %d/%d: selected h=%.4g\n',r,replications,h$h))
  }
  dir.create(output,recursive=TRUE,showWarnings=FALSE)
  tab<-do.call(rbind,rows)
  utils::write.csv(tab,file.path(output,'replications.csv'),row.names=FALSE)
  groups<-split(tab,paste(tab$interval,tab$target,tab$region,sep='/'))
  ss<-do.call(rbind,lapply(groups,function(z){
    idx<-!is.na(z$covered)
    data.frame(interval=z$interval[1],target=z$target[1],region=z$region[1],
       n_valid=sum(idx),n_total=nrow(z),
       coverage=if(any(idx)) mean(z$covered[idx]) else NA_real_,
       mean_width=if(any(idx)) mean(z$width[idx],na.rm=TRUE) else NA_real_)
  }))
  utils::write.csv(ss,file.path(output,'summary.csv'),row.names=FALSE)
  invisible(ss)
}

# Focused Case 1 demo: replicate the uploaded continuous-Z k=1 mechanism.
# This does not silently add binary-Z cases or all-index benchmarks absent
# from the uploaded source file.
demo_run_misallocation <- function(N,T,replications,seed_base,selection_seed,
                                   k,h_grid,output,cv_tol=1e-4,cv_maxit=30L,
                                   fit_tol=1e-6,fit_maxit=300L,batches=NULL) {
  theta<-c(1,1,1)/sqrt(3);beta<-c(1,-1,0.5,0.7,-0.5)
  order_z<-misallocation_order(length(beta),selection_seed)
  moved<-sort(order_z[seq_len(k)])
  stopifnot(k>=1L,k<length(beta))
  rows<-vector('list',replications)
  for(r in seq_len(replications)) {
    spec<-demo_rep_settings(r,batches,seed_base,h_grid)
    set.seed(spec$seed)
    dat<-generate_study12(N,T,theta,beta,1L,1L)
    view<-misallocation_view(dat,moved)
    h<-demo_choose_bandwidth(view$X,view$Z,view$Y,spec$h1,'Mth1',cv_tol,cv_maxit)
    fit<-demo_fit_proposed(view,h$h,fit_tol,fit_maxit)
    eff<-misallocation_effects_mth1(dat,view,fit,theta,beta,h$h)
    pred<-fit$a+z_linear_part(view$Z,fit$beta)
    rows[[r]]<-data.frame(rep=r,seed=spec$seed,k=k,
      moved_Z=paste(paste0('Z',moved),collapse=';'),selection_seed=selection_seed,
      selected_h=h$h,cv_mse=h$cv_mse,
      effect_mse=mean(eff$point_mse),
      signal_mse=mean((pred-(dat$Y-dat$e))^2),
      fit_mse=mean((pred-dat$Y)^2),
      iterations=fit$iter)
    cat(sprintf('Study 5 Case 1 rep %d/%d: moved %s, selected h=%.4g\n',
                r,replications,paste(moved,collapse=','),h$h))
  }
  dir.create(output,recursive=TRUE,showWarnings=FALSE)
  tab<-do.call(rbind,rows)
  utils::write.csv(tab,file.path(output,'replications.csv'),row.names=FALSE)
  ss<-data.frame(k=k,moved_Z=tab$moved_Z[1],replications=nrow(tab),
     mean_selected_h=mean(tab$selected_h),mean_cv_mse=mean(tab$cv_mse),
     mean_effect_mse=mean(tab$effect_mse),
     mean_signal_mse=mean(tab$signal_mse),
     mean_fit_mse=mean(tab$fit_mse))
  utils::write.csv(ss,file.path(output,'summary.csv'),row.names=FALSE)
  invisible(ss)
}
