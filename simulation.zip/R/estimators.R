# Shared paper estimators; active functions extracted from the two uploaded archives.
# Mth1 = ADE-start RMAVE (Gaussian kernel); Mth2 = all-index ADE/RMAVE (Gaussian).
# Mth3 = Chen et al. 2013a author-code-aligned FE estimator (Epanechnikov final kernel).
# Source-level provenance in FUNCTION_ORIGINS.csv; numerical functions are shared.

safe_ginv <- function(M, ridge = 1e-8) {
  M <- as.matrix(M)
  MASS::ginv(M + diag(ridge, nrow(M)))
}

normalize_vec <- function(x) {
  x <- as.numeric(x)
  nr <- sqrt(sum(x^2))
  if (!is.finite(nr) || nr < 1e-12) {
    out <- rep(0, length(x))
    out[1] <- 1
    return(out)
  }
  x <- x / nr
  nz <- which(abs(x) > 1e-10)[1]
  if (!is.na(nz) && x[nz] < 0) x <- -x
  x
}

K1 <- function(u) dnorm(u)

Kmulti <- function(u) {
  # Multiplicative normalising constants cancel in the OPG local fit.
  exp(-0.5 * sum(as.numeric(u)^2))
}

silverman_h <- function(n, d) {
  (4 / (d + 2))^(1 / (d + 4)) * n^(-1 / (d + 4))
}

stack_panel_3d <- function(A) {
  N <- dim(A)[1]; Tt <- dim(A)[2]; p <- dim(A)[3]
  out <- matrix(0, N * Tt, p)
  r <- 1
  for (i in 1:N) {
    for (t in 1:Tt) {
      out[r, ] <- as.numeric(A[i, t, ])
      r <- r + 1
    }
  }
  out
}

make_X_all <- function(X, Z) {
  N <- dim(X)[1]; Tt <- dim(X)[2]
  p1 <- dim(X)[3]; p2 <- dim(Z)[3]
  out <- array(0, c(N, Tt, p1 + p2))
  for (i in 1:N) for (t in 1:Tt) {
    out[i, t, ] <- c(as.numeric(X[i, t, ]), as.numeric(Z[i, t, ]))
  }
  out
}

z_linear_part <- function(Z, beta) {
  N <- dim(Z)[1]; Tt <- dim(Z)[2]
  out <- matrix(0, N, Tt)
  for (i in 1:N) for (t in 1:Tt) {
    out[i, t] <- sum(as.numeric(Z[i, t, ]) * beta)
  }
  out
}

opg_init_single_index <- function(W, Y) {
  N <- dim(W)[1]; Tt <- dim(W)[2]; p <- dim(W)[3]
  h0 <- silverman_h(Tt, p)
  A <- matrix(0, p, p)

  for (i in 1:N) {
    for (s in 1:Tt) {
      S1 <- matrix(0, 1 + p, 1 + p)
      S2 <- matrix(0, 1 + p, 1)

      for (t in 1:Tt) {
        if (t == s) next
        dw <- as.numeric(W[i, t, ] - W[i, s, ])
        w <- Kmulti(dw / h0)
        zloc <- c(1, dw)
        S1 <- S1 + w * tcrossprod(zloc)
        S2 <- S2 + w * matrix(zloc * Y[i, t], ncol = 1)
      }
      coef_loc <- safe_ginv(S1, 1e-6) %*% S2
      slope <- as.numeric(coef_loc[-1, 1])
      A <- A + tcrossprod(slope)
    }
  }
  eig <- eigen(A, symmetric = TRUE)
  normalize_vec(eig$vectors[, 1])
}

initial_beta_within_ADE <- function(Z, Y) {
  N <- dim(Z)[1]
  Tt <- dim(Z)[2]
  p2 <- dim(Z)[3]

  Zs <- matrix(0, N * Tt, p2)
  Ys <- numeric(N * Tt)
  rr <- 1L

  for (i in seq_len(N)) {
    Zi <- matrix(Z[i, , ], nrow = Tt, ncol = p2)
    yi <- as.numeric(Y[i, ])

    Zi_dm <- sweep(Zi, 2, colMeans(Zi), "-")
    yi_dm <- yi - mean(yi)

    idx <- rr:(rr + Tt - 1L)
    Zs[idx, ] <- Zi_dm
    Ys[idx] <- yi_dm
    rr <- rr + Tt
  }

  beta0 <- as.numeric(
    safe_ginv(crossprod(Zs), ridge = 1e-10) %*%
      crossprod(Zs, Ys)
  )

  beta0[!is.finite(beta0)] <- 0
  if (length(beta0) != p2) beta0 <- rep(0, p2)
  beta0
}

ade_local_gradient_initial <- function(
    X,
    Y_tilde,
    theta_reference = NULL,
    bw_mult = 1.0,
    trim = 0.10,
    ridge = 1e-6,
    leave_one_out = TRUE
) {
  N <- dim(X)[1]
  Tt <- dim(X)[2]
  p1 <- dim(X)[3]

  Xpool <- stack_panel_3d(X)
  xsd <- apply(Xpool, 2, sd)
  xsd[!is.finite(xsd) | xsd < 1e-8] <- 1

  # g_i is smoothed within individual, so T is the local smoothing size.
  hfac <- silverman_h(Tt, p1)
  bw_vec <- bw_mult * hfac * xsd
  bw_vec[!is.finite(bw_vec) | bw_vec < 1e-6] <- 0.10

  lower <- apply(
    Xpool, 2, quantile,
    probs = trim, names = FALSE, type = 7
  )
  upper <- apply(
    Xpool, 2, quantile,
    probs = 1 - trim, names = FALSE, type = 7
  )

  # OPG is used only as a REFERENCE DIRECTION for sign alignment.
  # It is not the ADE estimate returned below unless the ADE vector
  # is numerically degenerate and the explicit fallback is triggered.
  if (is.null(theta_reference)) {
    theta_reference <- opg_init_single_index(X, Y_tilde)
  }
  theta_reference <- normalize_vec(theta_reference)

  individual_ade <- matrix(NA_real_, N, p1)
  n_grad_i <- integer(N)
  all_slopes_for_dispersion <- list()
  ks <- 1L

  for (i in seq_len(N)) {
    slopes_trim <- list()
    slopes_all <- list()
    kt <- 1L
    ka <- 1L

    yi <- as.numeric(Y_tilde[i, ])

    for (s in seq_len(Tt)) {
      S1 <- matrix(0, 1 + p1, 1 + p1)
      S2 <- matrix(0, 1 + p1, 1)

      for (t in seq_len(Tt)) {
        if (isTRUE(leave_one_out) && t == s) next

        dx <- as.numeric(X[i, t, ] - X[i, s, ])
        u <- dx / bw_vec
        w <- exp(-0.5 * sum(u^2))
        if (!is.finite(w) || w <= 1e-14) next

        zloc <- c(1, dx)
        S1 <- S1 + w * tcrossprod(zloc)
        S2 <- S2 + w * matrix(zloc * yi[t], ncol = 1)
      }

      coef_loc <- safe_ginv(S1, ridge = ridge) %*% S2
      slope <- as.numeric(coef_loc[2:(p1 + 1), 1])

      if (all(is.finite(slope))) {
        slopes_all[[ka]] <- slope
        ka <- ka + 1L

        xs <- as.numeric(X[i, s, ])
        if (all(xs >= lower & xs <= upper)) {
          slopes_trim[[kt]] <- slope
          kt <- kt + 1L
        }
      }
    }

    slope_mat <- NULL
    if (length(slopes_trim) >= max(3L, p1 + 1L)) {
      slope_mat <- do.call(rbind, slopes_trim)
    } else if (length(slopes_all) > 0L) {
      slope_mat <- do.call(rbind, slopes_all)
    }

    if (!is.null(slope_mat) && nrow(as.matrix(slope_mat)) > 0L) {
      slope_mat <- as.matrix(slope_mat)
      di <- colMeans(slope_mat, na.rm = TRUE)

      if (all(is.finite(di)) && sqrt(sum(di^2)) > 1e-10) {
        # Heterogeneous g_i may give average derivative scalars of
        # different signs. Align only the sign, not the direction.
        if (sum(di * theta_reference) < 0) di <- -di
        individual_ade[i, ] <- di
        n_grad_i[i] <- nrow(slope_mat)

        for (jj in seq_len(nrow(slope_mat))) {
          ss <- as.numeric(slope_mat[jj, ])
          if (sum(ss * theta_reference) < 0) ss <- -ss
          all_slopes_for_dispersion[[ks]] <- ss
          ks <- ks + 1L
        }
      }
    }
  }

  good_i <- which(
    apply(individual_ade, 1, function(z) all(is.finite(z)))
  )

  fallback <- "none"

  if (length(good_i) > 0L) {
    ade_vec <- colMeans(individual_ade[good_i, , drop = FALSE])
  } else {
    ade_vec <- rep(NA_real_, p1)
  }

  if (!all(is.finite(ade_vec)) || sqrt(sum(ade_vec^2)) < 1e-8) {
    ade_vec <- theta_reference
    fallback <- "OPG_reference_due_to_degenerate_ADE_average"
  }

  slope_dispersion <- NA_real_
  if (length(all_slopes_for_dispersion) > 0L) {
    sm <- do.call(rbind, all_slopes_for_dispersion)
    center <- matrix(ade_vec, nrow(sm), p1, byrow = TRUE)
    slope_dispersion <- mean(rowSums((sm - center)^2))
  }

  list(
    theta = normalize_vec(ade_vec),
    ade_vector = as.numeric(ade_vec),
    individual_ade = individual_ade,
    bandwidth_vector = as.numeric(bw_vec),
    n_individuals_used = length(good_i),
    n_gradients_used = sum(n_grad_i),
    n_gradients_by_individual = n_grad_i,
    theta_reference = theta_reference,
    gradient_dispersion = slope_dispersion,
    fallback = fallback
  )
}

init_method1_ADE <- function(
    X,
    Z,
    Y,
    bw_mult = get0("ADE_INIT_BW_MULT", ifnotfound = 1.0, inherits = TRUE),
    trim = get0("ADE_INIT_TRIM", ifnotfound = 0.10, inherits = TRUE),
    ridge = get0("ADE_INIT_RIDGE", ifnotfound = 1e-6, inherits = TRUE),
    leave_one_out = get0("ADE_INIT_LEAVE_ONE_OUT", ifnotfound = TRUE, inherits = TRUE)
) {
  beta0 <- initial_beta_within_ADE(Z, Y)
  Y_tilde <- Y - z_linear_part(Z, beta0)

  # Numerical reference used ONLY to align ADE signs.
  theta_ref <- opg_init_single_index(X, Y_tilde)

  ade <- ade_local_gradient_initial(
    X = X,
    Y_tilde = Y_tilde,
    theta_reference = theta_ref,
    bw_mult = bw_mult,
    trim = trim,
    ridge = ridge,
    leave_one_out = leave_one_out
  )

  list(
    theta = ade$theta,
    beta = beta0,
    ade_vector = ade$ade_vector,
    individual_ade = ade$individual_ade,
    bandwidth_vector = ade$bandwidth_vector,
    n_individuals_used = ade$n_individuals_used,
    n_gradients_used = ade$n_gradients_used,
    n_gradients_by_individual = ade$n_gradients_by_individual,
    theta_reference = ade$theta_reference,
    gradient_dispersion = ade$gradient_dispersion,
    fallback = ade$fallback,
    bw_mult = bw_mult,
    trim = trim,
    ridge = ridge,
    leave_one_out = leave_one_out
  )
}

init_method2_ADE <- function(
    X, Z, Y,
    bw_mult = get0("ADE_INIT_BW_MULT", ifnotfound = 1.0, inherits = TRUE),
    trim = get0("ADE_INIT_TRIM", ifnotfound = 0.10, inherits = TRUE),
    ridge = get0("ADE_INIT_RIDGE", ifnotfound = 1e-6, inherits = TRUE),
    leave_one_out = get0("ADE_INIT_LEAVE_ONE_OUT", ifnotfound = TRUE,
                         inherits = TRUE)
) {
  W <- make_X_all(X, Z)
  theta_ref <- opg_init_single_index(W, Y)

  ade <- ade_local_gradient_initial(
    X = W,
    Y_tilde = Y,
    theta_reference = theta_ref,
    bw_mult = bw_mult,
    trim = trim,
    ridge = ridge,
    leave_one_out = leave_one_out
  )

  list(
    theta_all = ade$theta,
    ade_vector = ade$ade_vector,
    individual_ade = ade$individual_ade,
    bandwidth_vector = ade$bandwidth_vector,
    n_individuals_used = ade$n_individuals_used,
    n_gradients_used = ade$n_gradients_used,
    theta_reference = ade$theta_reference,
    gradient_dispersion = ade$gradient_dispersion,
    fallback = ade$fallback
  )
}

init_method1 <- function(X, Z, Y) {
  ans <- init_method1_ADE(X, Z, Y)
  list(theta = ans$theta, beta = ans$beta,
       preliminary_method = "ADE_type_average_derivative", ade_info = ans)
}

init_method2 <- function(X, Z, Y) {
  ans <- init_method2_ADE(X, Z, Y)
  list(theta_all = ans$theta_all,
       preliminary_method = "ADE_type_average_derivative", ade_info = ans)
}

fit_method1 <- function(X, Z, Y, h,
                        theta_init = NULL, beta_init = NULL,
                        toler = 1e-6, maxit = 200) {
  N <- dim(X)[1]; Tt <- dim(X)[2]
  p1 <- dim(X)[3]; p2 <- dim(Z)[3]

  hvec <- if (length(h) == 1) rep(h, N) else as.numeric(h)
  if (length(hvec) != N) stop("h must be scalar or have length N.")

  if (is.null(theta_init) || is.null(beta_init)) {
    init <- init_method1(X, Z, Y)
    theta <- init$theta
    beta <- init$beta
  } else {
    theta <- normalize_vec(theta_init)
    beta <- as.numeric(beta_init)
  }

  init_theta <- theta
  init_beta <- beta
  one_theta <- NA
  one_beta <- NA

  a <- matrix(0, N, Tt)
  b <- matrix(0, N, Tt)
  delta <- Inf
  it <- 0

  while (delta > toler && it < maxit) {
    it <- it + 1
    theta_old <- theta
    beta_old <- beta

    x <- array(0, c(N, Tt, Tt))
    Kh <- array(0, c(N, Tt, Tt))

    for (i in 1:N) {
      hi <- hvec[i]
      for (t in 1:Tt) for (s in 1:Tt) {
        x[i, t, s] <- sum(theta * as.numeric(X[i, t, ] - X[i, s, ]))
        Kh[i, t, s] <- K1(x[i, t, s] / hi) / hi
      }
    }

    for (i in 1:N) {
      for (s in 1:Tt) {
        S1 <- matrix(0, 2, 2)
        S2 <- matrix(0, 2, 1)
        for (t in 1:Tt) {
          zloc <- c(1, x[i, t, s])
          yres <- Y[i, t] - sum(as.numeric(Z[i, t, ]) * beta)
          w <- Kh[i, t, s]
          S1 <- S1 + w * tcrossprod(zloc)
          S2 <- S2 + w * matrix(zloc * yres, ncol = 1)
        }
        cc <- safe_ginv(S1) %*% S2
        a[i, s] <- cc[1, 1]
        b[i, s] <- cc[2, 1]
      }
    }

    f <- matrix(0, N, Tt)
    for (i in 1:N) for (s in 1:Tt) f[i, s] <- mean(Kh[i, , s])

    S3 <- matrix(0, p1 + p2, p1 + p2)
    S4 <- matrix(0, p1 + p2, 1)

    for (i in 1:N) for (t in 1:Tt) for (s in 1:Tt) {
      if (!is.finite(f[i, s]) || f[i, s] < 1e-12) next
      dx <- as.numeric(X[i, t, ] - X[i, s, ])
      vec <- c(as.numeric(Z[i, t, ]), b[i, s] * dx)
      w <- Kh[i, t, s] / f[i, s]
      S3 <- S3 + w * tcrossprod(vec)
      S4 <- S4 + w * matrix(vec * (Y[i, t] - a[i, s]), ncol = 1)
    }

    global <- safe_ginv(S3) %*% S4
    beta <- as.numeric(global[1:p2, 1])
    theta <- normalize_vec(global[(p2 + 1):(p1 + p2), 1])

    if (it == 1) {
      one_beta <- beta
      one_theta <- theta
    }

    delta <- sqrt(sum((beta - beta_old)^2)) +
      sqrt(sum((theta - theta_old)^2))
  }

  list(theta = theta, beta = beta, a = a, b = b,
       init_theta = init_theta, init_beta = init_beta,
       one_theta = one_theta, one_beta = one_beta,
       iter = it, delta = delta, h = hvec)
}

fit_method2 <- function(X, Z, Y, h,
                        theta_init = NULL,
                        toler = 1e-6, maxit = 200) {
  Xall <- make_X_all(X, Z)
  N <- dim(Xall)[1]; Tt <- dim(Xall)[2]; p <- dim(Xall)[3]

  if (is.null(theta_init)) {
    theta <- init_method2(X, Z, Y)$theta_all
  } else {
    theta <- normalize_vec(theta_init)
  }

  a <- matrix(0, N, Tt)
  b <- matrix(0, N, Tt)
  delta <- Inf
  it <- 0

  while (delta > toler && it < maxit) {
    it <- it + 1
    theta_old <- theta

    x <- array(0, c(N, Tt, Tt))
    Kh <- array(0, c(N, Tt, Tt))

    for (i in 1:N) for (t in 1:Tt) for (s in 1:Tt) {
      x[i, t, s] <- sum(theta * as.numeric(Xall[i, t, ] - Xall[i, s, ]))
      Kh[i, t, s] <- K1(x[i, t, s] / h) / h
    }

    for (i in 1:N) for (s in 1:Tt) {
      S1 <- matrix(0, 2, 2)
      S2 <- matrix(0, 2, 1)
      for (t in 1:Tt) {
        zloc <- c(1, x[i, t, s])
        w <- Kh[i, t, s]
        S1 <- S1 + w * tcrossprod(zloc)
        S2 <- S2 + w * matrix(zloc * Y[i, t], ncol = 1)
      }
      cc <- safe_ginv(S1) %*% S2
      a[i, s] <- cc[1, 1]
      b[i, s] <- cc[2, 1]
    }

    f <- matrix(0, N, Tt)
    for (i in 1:N) for (s in 1:Tt) f[i, s] <- mean(Kh[i, , s])

    S3 <- matrix(0, p, p)
    S4 <- matrix(0, p, 1)
    for (i in 1:N) for (t in 1:Tt) for (s in 1:Tt) {
      if (!is.finite(f[i, s]) || f[i, s] < 1e-12) next
      dx <- as.numeric(Xall[i, t, ] - Xall[i, s, ])
      vec <- b[i, s] * dx
      w <- Kh[i, t, s] / f[i, s]
      S3 <- S3 + w * tcrossprod(vec)
      S4 <- S4 + w * matrix(vec * (Y[i, t] - a[i, s]), ncol = 1)
    }

    theta <- normalize_vec(as.numeric(safe_ginv(S3) %*% S4))
    delta <- sqrt(sum((theta - theta_old)^2))
  }

  list(theta_all = theta, a_all = a, b_all = b,
       iter = it, delta = delta, h = h)
}

predict_method1_fold <- function(fit, X_train, Z_train, Y_train,
                                 X_test, Z_test, h) {
  N <- dim(X_train)[1]; Tt <- dim(X_train)[2]
  out <- numeric(N)

  for (i in 1:N) {
    hi <- if (length(h) == 1) h else h[i]
    S1 <- matrix(0, 2, 2)
    S2 <- matrix(0, 2, 1)

    for (t in 1:Tt) {
      d <- sum(fit$theta * as.numeric(X_train[i, t, ] - X_test[i, 1, ]))
      w <- K1(d / hi) / hi
      zloc <- c(1, d)
      yres <- Y_train[i, t] - sum(as.numeric(Z_train[i, t, ]) * fit$beta)
      S1 <- S1 + w * tcrossprod(zloc)
      S2 <- S2 + w * matrix(zloc * yres, ncol = 1)
    }
    g0 <- (safe_ginv(S1) %*% S2)[1, 1]
    out[i] <- g0 + sum(as.numeric(Z_test[i, 1, ]) * fit$beta)
  }
  out
}

predict_method2_fold <- function(fit, Xall_train, Y_train, Xall_test, h) {
  N <- dim(Xall_train)[1]; Tt <- dim(Xall_train)[2]
  out <- numeric(N)

  for (i in 1:N) {
    S1 <- matrix(0, 2, 2)
    S2 <- matrix(0, 2, 1)
    for (t in 1:Tt) {
      d <- sum(fit$theta_all * as.numeric(Xall_train[i, t, ] - Xall_test[i, 1, ]))
      w <- K1(d / h) / h
      zloc <- c(1, d)
      S1 <- S1 + w * tcrossprod(zloc)
      S2 <- S2 + w * matrix(zloc * Y_train[i, t], ncol = 1)
    }
    out[i] <- (safe_ginv(S1) %*% S2)[1, 1]
  }
  out
}

cv_curve_method1 <- function(X, Z, Y, h_grid, toler = 1e-4, maxit = 30) {
  N <- dim(X)[1]; Tt <- dim(X)[2]
  sse <- numeric(length(h_grid))

  for (s_test in 1:Tt) {
    tr <- setdiff(1:Tt, s_test)
    Xtr <- X[, tr, , drop = FALSE]
    Ztr <- Z[, tr, , drop = FALSE]
    Ytr <- Y[, tr, drop = FALSE]
    init <- init_method1(Xtr, Ztr, Ytr)

    for (k in seq_along(h_grid)) {
      h <- h_grid[k]
      fit <- fit_method1(Xtr, Ztr, Ytr, h,
                         theta_init = init$theta, beta_init = init$beta,
                         toler = toler, maxit = maxit)
      pred <- predict_method1_fold(
        fit, Xtr, Ztr, Ytr,
        X[, s_test, , drop = FALSE],
        Z[, s_test, , drop = FALSE], h
      )
      sse[k] <- sse[k] + sum((Y[, s_test] - pred)^2)
    }
  }
  sse / (N * Tt)
}

cv_curve_method2 <- function(X, Z, Y, h_grid, toler = 1e-4, maxit = 30) {
  Xall <- make_X_all(X, Z)
  N <- dim(X)[1]; Tt <- dim(X)[2]
  sse <- numeric(length(h_grid))

  for (s_test in 1:Tt) {
    tr <- setdiff(1:Tt, s_test)
    Xtr <- X[, tr, , drop = FALSE]
    Ztr <- Z[, tr, , drop = FALSE]
    Ytr <- Y[, tr, drop = FALSE]
    Xall_tr <- Xall[, tr, , drop = FALSE]
    Xall_te <- Xall[, s_test, , drop = FALSE]
    init <- init_method2(Xtr, Ztr, Ytr)

    for (k in seq_along(h_grid)) {
      h <- h_grid[k]
      fit <- fit_method2(Xtr, Ztr, Ytr, h,
                         theta_init = init$theta_all,
                         toler = toler, maxit = maxit)
      pred <- predict_method2_fold(fit, Xall_tr, Ytr, Xall_te, h)
      sse[k] <- sse[k] + sum((Y[, s_test] - pred)^2)
    }
  }
  sse / (N * Tt)
}

estimate_g_method1_at <- function(i, v0, fit, X, Z, Y, h) {
  Tt <- dim(X)[2]
  hi <- if (length(h) == 1) h else h[i]
  S1 <- matrix(0, 2, 2)
  S2 <- matrix(0, 2, 1)

  for (t in 1:Tt) {
    vit <- sum(fit$theta * as.numeric(X[i, t, ]))
    d <- vit - v0
    w <- K1(d / hi) / hi
    zloc <- c(1, d)
    yres <- Y[i, t] - sum(as.numeric(Z[i, t, ]) * fit$beta)
    S1 <- S1 + w * tcrossprod(zloc)
    S2 <- S2 + w * matrix(zloc * yres, ncol = 1)
  }
  (safe_ginv(S1) %*% S2)[1, 1]
}

estimate_g_method2_at <- function(i, v0, fit, Xall, Y, h) {
  Tt <- dim(Xall)[2]
  S1 <- matrix(0, 2, 2)
  S2 <- matrix(0, 2, 1)

  for (t in 1:Tt) {
    vit <- sum(fit$theta_all * as.numeric(Xall[i, t, ]))
    d <- vit - v0
    w <- K1(d / h) / h
    zloc <- c(1, d)
    S1 <- S1 + w * tcrossprod(zloc)
    S2 <- S2 + w * matrix(zloc * Y[i, t], ncol = 1)
  }
  (safe_ginv(S1) %*% S2)[1, 1]
}

evaluate_effects_two_methods <- function(dat, fit1, fit2,
                                         theta_true, beta_true,
                                         h1, h2) {
  X <- dat$X; Z <- dat$Z; Y <- dat$Y
  Xall <- make_X_all(X, Z)
  N <- dim(X)[1]; Tt <- dim(X)[2]
  p1 <- dim(X)[3]; p2 <- dim(Z)[3]

  true_eff <- matrix(NA_real_, N * Tt, p1 + p2)
  m1_eff <- matrix(NA_real_, N * Tt, p1 + p2)
  m2_eff <- matrix(NA_real_, N * Tt, p1 + p2)
  types <- c(dat$X_types, dat$Z_types)
  varnames <- c(paste0("X", 1:p1), paste0("Z", 1:p2))

  rr <- 1
  for (i in 1:N) {
    g <- dat$g_list[[i]]
    gp <- dat$gp_list[[i]]

    for (t in 1:Tt) {
      xvec <- as.numeric(X[i, t, ])
      zvec <- as.numeric(Z[i, t, ])
      eta_true <- sum(theta_true * xvec)
      eta1 <- sum(fit1$theta * xvec)
      full <- c(xvec, zvec)
      eta2 <- sum(fit2$theta_all * full)

      # X effects
      for (j in 1:p1) {
        if (dat$X_types[j] == "continuous") {
          true_eff[rr, j] <- gp(eta_true) * theta_true[j]
          m1_eff[rr, j] <- fit1$b[i, t] * fit1$theta[j]
          m2_eff[rr, j] <- fit2$b_all[i, t] * fit2$theta_all[j]
        } else {
          eta_true_minus <- eta_true - theta_true[j] * xvec[j]
          true_eff[rr, j] <- g(eta_true_minus + theta_true[j]) - g(eta_true_minus)

          eta1_minus <- eta1 - fit1$theta[j] * xvec[j]
          m1_eff[rr, j] <-
            estimate_g_method1_at(i, eta1_minus + fit1$theta[j], fit1, X, Z, Y, h1) -
            estimate_g_method1_at(i, eta1_minus, fit1, X, Z, Y, h1)

          eta2_minus <- eta2 - fit2$theta_all[j] * xvec[j]
          m2_eff[rr, j] <-
            estimate_g_method2_at(i, eta2_minus + fit2$theta_all[j], fit2, Xall, Y, h2) -
            estimate_g_method2_at(i, eta2_minus, fit2, Xall, Y, h2)
        }
      }

      # Z effects
      for (j in 1:p2) {
        pos <- p1 + j
        true_eff[rr, pos] <- beta_true[j]
        m1_eff[rr, pos] <- fit1$beta[j]

        if (dat$Z_types[j] == "continuous") {
          m2_eff[rr, pos] <- fit2$b_all[i, t] * fit2$theta_all[pos]
        } else {
          eta2_minus <- eta2 - fit2$theta_all[pos] * zvec[j]
          m2_eff[rr, pos] <-
            estimate_g_method2_at(i, eta2_minus + fit2$theta_all[pos], fit2, Xall, Y, h2) -
            estimate_g_method2_at(i, eta2_minus, fit2, Xall, Y, h2)
        }
      }
      rr <- rr + 1
    }
  }

  rows <- list()
  q <- 1
  for (j in 1:(p1 + p2)) {

    if (j <= p1) {
      # X variables:
      # continuous X -> derivative effect;
      # binary X -> finite 0-to-1 discrete change.
      effect_type_m1 <- if (types[j] == "binary") {
        "discrete_change_0_to_1"
      } else {
        "derivative"
      }
      effect_type_m2 <- effect_type_m1
    } else {
      # Z variables:
      # Mth1 keeps Z in the linear component.
      # Mth2 places Z inside the nonparametric single index.
      effect_type_m1 <- if (types[j] == "binary") {
        "linear_discrete_change_0_to_1"
      } else {
        "linear_coefficient"
      }
      effect_type_m2 <- if (types[j] == "binary") {
        "discrete_change_0_to_1"
      } else {
        "derivative"
      }
    }

    rows[[q]] <- data.frame(
      method = "Mth1_proposed",
      variable = varnames[j],
      variable_type = types[j],
      effect_type = effect_type_m1,
      true_avg = mean(true_eff[, j]),
      est_avg = mean(m1_eff[, j]),
      point_mse = mean((m1_eff[, j] - true_eff[, j])^2)
    )
    q <- q + 1

    rows[[q]] <- data.frame(
      method = "Mth2_Chen2013b",
      variable = varnames[j],
      variable_type = types[j],
      effect_type = effect_type_m2,
      true_avg = mean(true_eff[, j]),
      est_avg = mean(m2_eff[, j]),
      point_mse = mean((m2_eff[, j] - true_eff[, j])^2)
    )
    q <- q + 1
  }
  do.call(rbind, rows)
}

build_D_matrix <- function(N, Tt) {
  if (N <= 1) return(matrix(0, N * Tt, 0))
  A <- t(cbind(-rep(1, N - 1), diag(N - 1)))  # N x (N-1)
  kronecker(A, matrix(1, Tt, 1))
}

chen2013a_pinv_authors_code <- function(A, tol = NULL) {
  A <- as.matrix(A)
  if (length(A) == 0) {
    return(matrix(0, ncol(A), nrow(A)))
  }

  ss <- svd(A)
  if (length(ss$d) == 0 || !any(is.finite(ss$d))) {
    return(matrix(0, ncol(A), nrow(A)))
  }

  dmax <- max(ss$d, na.rm = TRUE)
  if (is.null(tol)) {
    tol <- max(dim(A)) * .Machine$double.eps * dmax
  }

  dinv <- ifelse(ss$d > tol, 1 / ss$d, 0)
  ss$v %*% diag(dinv, nrow = length(dinv)) %*% t(ss$u)
}

chen2013a_initial_authors_code <- function(X, Z, Y, init_iter = 50) {
  N <- dim(X)[1]
  Tt <- dim(X)[2]
  p1 <- dim(X)[3]
  p2 <- dim(Z)[3]
  M <- N * Tt

  Xmat <- stack_panel_3d(X)
  Zmat <- stack_panel_3d(Z)
  Yvec <- as.vector(t(Y))
  D <- build_D_matrix(N, Tt)

  balpha <- if (N > 1) rep(0, N - 1) else numeric(0)

  if (p1 == 3) {
    theta <- normalize_vec(c(0, 1, 2))
  } else {
    theta <- normalize_vec(rep(1, p1))
  }

  beta <- as.numeric(
    chen2013a_pinv_authors_code(crossprod(Zmat)) %*%
      crossprod(Zmat, Yvec)
  )

  xcenter <- sweep(Xmat, 2, colMeans(Xmat), "-")
  sigma5 <- sqrt(mean(rowSums(xcenter^2)))

  # PLSI.m has exponent -1/7 because p1=3. Use the general -1/(4+p1).
  h1 <- sigma5 * M^(-1 / (4 + p1))
  if (!is.finite(h1) || h1 <= 0) {
    h1 <- M^(-1 / (4 + p1))
  }

  for (iter in seq_len(init_iter)) {
    alpha_obs <- if (N > 1) as.numeric(D %*% balpha) else rep(0, M)
    ye <- Yvec - as.numeric(Zmat %*% beta) - alpha_obs

    S1diag <- numeric(M)
    S2 <- numeric(M)
    S3 <- matrix(0, M, p2 + p1)
    S4 <- matrix(0, p2 + p1, 1)
    S5 <- matrix(0, p2 + p1, p2 + p1)

    for (l in seq_len(M)) {
      xl <- sweep(Xmat, 2, Xmat[l, ], "-")
      kl <- exp(-rowSums(xl^2) / (2 * h1^2))
      if (!all(is.finite(kl)) || sum(kl) <= 0) {
        kl <- rep(1, M)
      }
      wl <- kl / sum(kl)

      xproj <- as.numeric(xl %*% theta)
      Xloc <- cbind(1, xproj)
      abl <- chen2013a_pinv_authors_code(
        crossprod(Xloc, Xloc * wl)
      ) %*% crossprod(Xloc, ye * wl)

      a_l <- abl[1, 1]
      b_l <- abl[2, 1]
      TYl <- Yvec - a_l
      ZXl <- cbind(Zmat, b_l * xl)

      S1diag <- S1diag + wl
      S2 <- S2 + wl * TYl
      S3 <- S3 + ZXl * wl
      S4 <- S4 + crossprod(ZXl, wl * TYl)
      S5 <- S5 + crossprod(ZXl, ZXl * wl)
    }

    if (N > 1) {
      Ainv <- chen2013a_pinv_authors_code(
        crossprod(D, D * S1diag)
      )
      SS2 <- crossprod(D, S2)
      SS3 <- crossprod(D, S3)

      global <- chen2013a_pinv_authors_code(
        S5 - t(SS3) %*% Ainv %*% SS3
      ) %*% (
        S4 - t(SS3) %*% Ainv %*% SS2
      )

      balpha <- as.numeric(
        Ainv %*% (SS2 - SS3 %*% global)
      )
    } else {
      global <- chen2013a_pinv_authors_code(S5) %*% S4
    }

    beta <- as.numeric(global[seq_len(p2), 1])
    theta <- normalize_vec(
      global[(p2 + 1):(p2 + p1), 1]
    )
  }

  list(
    beta = beta,
    theta = theta,
    balpha = balpha,
    h1 = h1
  )
}

chen2013a_final_kernel_article <- function(u) {
  u <- as.numeric(u)
  0.75 * (1 - u^2) * (abs(u) <= 1)
}

chen2013a_final_ab_authors_code <- function(
    X,
    Z,
    Y,
    h,
    beta,
    theta,
    alpha
) {
  N <- dim(X)[1]
  Tt <- dim(X)[2]
  M <- N * Tt

  Xmat <- stack_panel_3d(X)
  Zmat <- stack_panel_3d(Z)
  Yvec <- as.vector(t(Y))

  alpha_obs <- rep(alpha, each = Tt)
  ye <- Yvec - as.numeric(Zmat %*% beta) - alpha_obs

  a <- numeric(M)
  b <- numeric(M)

  for (l in seq_len(M)) {
    xl <- sweep(Xmat, 2, Xmat[l, ], "-")
    xproj <- as.numeric(xl %*% theta)

    # Chen et al. (2013a), Section 5: quadratic/Epanechnikov kernel.
    kl <- chen2013a_final_kernel_article(xproj / h)
    if (!all(is.finite(kl)) || sum(kl) <= 0) {
      stop("Chen2013a final local fit has zero/invalid kernel weight; enlarge h_grid.")
    }
    wl <- kl / sum(kl)

    Xloc <- cbind(1, xproj)
    abl <- chen2013a_pinv_authors_code(
      crossprod(Xloc, Xloc * wl)
    ) %*% crossprod(Xloc, ye * wl)

    a[l] <- abl[1, 1]
    b[l] <- abl[2, 1]
  }

  list(
    a = matrix(a, N, Tt, byrow = TRUE),
    b = matrix(b, N, Tt, byrow = TRUE)
  )
}

chen2013a_refine_authors_code <- function(
    X,
    Z,
    Y,
    h,
    init_state,
    toler = 1e-5,
    maxit = 100
) {
  N <- dim(X)[1]
  Tt <- dim(X)[2]
  p1 <- dim(X)[3]
  p2 <- dim(Z)[3]
  M <- N * Tt

  Xmat <- stack_panel_3d(X)
  Zmat <- stack_panel_3d(Z)
  Yvec <- as.vector(t(Y))
  D <- build_D_matrix(N, Tt)

  theta <- init_state$theta
  beta <- init_state$beta
  balpha <- init_state$balpha

  delta <- Inf
  it <- 0

  while (delta > toler && it < maxit) {
    it <- it + 1
    theta_old <- theta
    beta_old <- beta

    alpha_obs <- if (N > 1) as.numeric(D %*% balpha) else rep(0, M)
    ye <- Yvec - as.numeric(Zmat %*% beta) - alpha_obs

    S1diag <- numeric(M)
    S2 <- numeric(M)
    S3 <- matrix(0, M, p2 + p1)
    S4 <- matrix(0, p2 + p1, 1)
    S5 <- matrix(0, p2 + p1, p2 + p1)

    for (l in seq_len(M)) {
      xl <- sweep(Xmat, 2, Xmat[l, ], "-")
      xproj <- as.numeric(xl %*% theta)

      kl <- chen2013a_final_kernel_article(xproj / h)
      if (!all(is.finite(kl)) || sum(kl) <= 0) {
        stop("Chen2013a final SMAVE step has zero/invalid kernel weight; enlarge h_grid.")
      }
      wl <- kl / sum(kl)

      Xloc <- cbind(1, xproj)
      abl <- chen2013a_pinv_authors_code(
        crossprod(Xloc, Xloc * wl)
      ) %*% crossprod(Xloc, ye * wl)

      a_l <- abl[1, 1]
      b_l <- abl[2, 1]
      TYl <- Yvec - a_l
      ZXl <- cbind(Zmat, b_l * xl)

      S1diag <- S1diag + wl
      S2 <- S2 + wl * TYl
      S3 <- S3 + ZXl * wl
      S4 <- S4 + crossprod(ZXl, wl * TYl)
      S5 <- S5 + crossprod(ZXl, ZXl * wl)
    }

    if (N > 1) {
      Ainv <- chen2013a_pinv_authors_code(
        crossprod(D, D * S1diag)
      )
      SS2 <- crossprod(D, S2)
      SS3 <- crossprod(D, S3)

      global <- chen2013a_pinv_authors_code(
        S5 - t(SS3) %*% Ainv %*% SS3
      ) %*% (
        S4 - t(SS3) %*% Ainv %*% SS2
      )

      balpha <- as.numeric(
        Ainv %*% (SS2 - SS3 %*% global)
      )
    } else {
      global <- chen2013a_pinv_authors_code(S5) %*% S4
    }

    beta <- as.numeric(global[seq_len(p2), 1])
    theta <- normalize_vec(
      global[(p2 + 1):(p2 + p1), 1]
    )

    # PLSI.m compares (beta,theta) with the simulation truth. For a feasible
    # estimator, use consecutive (beta,theta) iterates, but do NOT add alpha.
    delta <- sqrt(
      sum((beta - beta_old)^2) +
        sum((theta - theta_old)^2)
    )
  }

  if (N > 1) {
    Aunit <- t(cbind(-rep(1, N - 1), diag(N - 1)))
    alpha_unit <- as.numeric(Aunit %*% balpha)
  } else {
    alpha_unit <- 0
  }

  # Re-evaluate the local-linear intercept/slope at the FINAL parameters.
  ab_final <- chen2013a_final_ab_authors_code(
    X = X,
    Z = Z,
    Y = Y,
    h = h,
    beta = beta,
    theta = theta,
    alpha = alpha_unit
  )

  list(
    beta = beta,
    theta = theta,
    alpha = alpha_unit,
    a = ab_final$a,
    b = ab_final$b,
    iter = it,
    delta = delta,
    h = h,
    converged = is.finite(delta) && delta <= toler
  )
}

fit_chen2013a_authors_code <- function(
    X,
    Z,
    Y,
    h,
    init_iter = 50,
    toler = 1e-5,
    maxit = 100
) {
  st <- chen2013a_initial_authors_code(
    X,
    Z,
    Y,
    init_iter = init_iter
  )

  chen2013a_refine_authors_code(
    X,
    Z,
    Y,
    h,
    st,
    toler = toler,
    maxit = maxit
  )
}

predict_chen2013a_common_part_authors_code <- function(
    fit,
    X_train,
    Z_train,
    Y_train,
    X_test,
    Z_test,
    h
) {
  Ntr <- dim(X_train)[1]
  Ttr <- dim(X_train)[2]
  Ttest <- dim(X_test)[2]

  Xmat <- stack_panel_3d(X_train)
  Zmat <- stack_panel_3d(Z_train)
  Yvec <- as.vector(t(Y_train))

  alpha_obs <- rep(fit$alpha, each = Ttr)
  yres <- Yvec - as.numeric(Zmat %*% fit$beta) - alpha_obs
  vtrain <- as.numeric(Xmat %*% fit$theta)

  out <- numeric(Ttest)

  for (t0 in seq_len(Ttest)) {
    v0 <- sum(
      fit$theta * as.numeric(X_test[1, t0, ])
    )
    d <- vtrain - v0

    kl <- chen2013a_final_kernel_article(d / h)
    if (!all(is.finite(kl)) || sum(kl) <= 0) {
      # With compact support, a too-small h can leave a held-out point
      # without training observations in its kernel window.  Mark this
      # candidate prediction invalid; the CV function assigns Inf.
      out[t0] <- NA_real_
      next
    }
    wl <- kl / sum(kl)

    Xloc <- cbind(1, d)
    g0 <- (
      chen2013a_pinv_authors_code(
        crossprod(Xloc, Xloc * wl)
      ) %*% crossprod(Xloc, yres * wl)
    )[1, 1]

    out[t0] <- g0 +
      sum(
        as.numeric(Z_test[1, t0, ]) * fit$beta
      )
  }

  out
}

cv_curve_chen2013a_authors_code <- function(
    X,
    Z,
    Y,
    h_grid,
    init_iter = 50,
    toler = 1e-5,
    maxit = 100
) {
  N <- dim(X)[1]
  Tt <- dim(X)[2]

  if (N <= 1) {
    stop("Chen2013a leave-one-individual-out CV requires N >= 2.")
  }

  sse <- numeric(length(h_grid))

  # Chen et al. (2013a): leave ONE WHOLE INDIVIDUAL out.
  for (i_test in seq_len(N)) {
    keep <- setdiff(seq_len(N), i_test)

    Xtr <- X[keep, , , drop = FALSE]
    Ztr <- Z[keep, , , drop = FALSE]
    Ytr <- Y[keep, , drop = FALSE]

    Xte <- X[i_test, , , drop = FALSE]
    Zte <- Z[i_test, , , drop = FALSE]
    Yte <- as.numeric(Y[i_test, ])

    # Initial 50-step state is independent of the final candidate h.
    st <- chen2013a_initial_authors_code(
      Xtr,
      Ztr,
      Ytr,
      init_iter = init_iter
    )

    for (k in seq_along(h_grid)) {
      h <- h_grid[k]

      fit <- chen2013a_refine_authors_code(
        Xtr,
        Ztr,
        Ytr,
        h,
        st,
        toler = toler,
        maxit = maxit
      )

      # Do NOT add alpha_i for the held-out individual: it was not estimated.
      # Instead Chen's M matrix removes the held-out individual fixed effect.
      pred_common <- predict_chen2013a_common_part_authors_code(
        fit = fit,
        X_train = Xtr,
        Z_train = Ztr,
        Y_train = Ytr,
        X_test = Xte,
        Z_test = Zte,
        h = h
      )

      if (any(!is.finite(pred_common))) {
        sse[k] <- Inf
      } else if (is.finite(sse[k])) {
        resid_i <- Yte - pred_common
        resid_i_within <- resid_i - mean(resid_i)
        sse[k] <- sse[k] + sum(resid_i_within^2)
      }
    }
  }

  sse / (N * Tt)
}

evaluate_effects_prop_chen_unified <- function(dat, fit_prop, fit_chen, theta_true, beta_true) {
  N <- dim(dat$X)[1]; Tt <- dim(dat$X)[2]
  p1 <- dim(dat$X)[3]; p2 <- dim(dat$Z)[3]
  rows <- list(); q <- 1L
  true_x <- matrix(NA_real_, N * Tt, p1)
  prop_x <- matrix(NA_real_, N * Tt, p1)
  chen_x <- matrix(NA_real_, N * Tt, p1)
  rr <- 1L
  for (i in seq_len(N)) {
    gp <- dat$gp_list[[i]]
    for (tt in seq_len(Tt)) {
      eta <- sum(theta_true * as.numeric(dat$X[i, tt, ]))
      for (j in seq_len(p1)) {
        true_x[rr, j] <- gp(eta) * theta_true[j]
        prop_x[rr, j] <- fit_prop$b[i, tt] * fit_prop$theta[j]
        chen_x[rr, j] <- fit_chen$b[i, tt] * fit_chen$theta[j]
      }
      rr <- rr + 1L
    }
  }
  for (j in seq_len(p1)) {
    for (obj in list(
      list(method = "Mth1_proposed", est = prop_x[, j]),
      list(method = "Mth3_Chen2013a", est = chen_x[, j])
    )) {
      rows[[q]] <- data.frame(
        method = obj$method, variable = paste0("X", j), variable_type = dat$X_types[j],
        effect_type = "derivative", true_avg = mean(true_x[, j]), est_avg = mean(obj$est),
        point_mse = mean((obj$est - true_x[, j])^2), stringsAsFactors = FALSE
      ); q <- q + 1L
    }
  }
  for (j in seq_len(p2)) {
    etype <- if (dat$Z_types[j] == "binary") "linear_discrete_change_0_to_1" else "linear_coefficient"
    for (obj in list(
      list(method = "Mth1_proposed", est = fit_prop$beta[j]),
      list(method = "Mth3_Chen2013a", est = fit_chen$beta[j])
    )) {
      rows[[q]] <- data.frame(
        method = obj$method, variable = paste0("Z", j), variable_type = dat$Z_types[j],
        effect_type = etype, true_avg = beta_true[j], est_avg = obj$est,
        point_mse = (obj$est - beta_true[j])^2, stringsAsFactors = FALSE
      ); q <- q + 1L
    }
  }
  do.call(rbind, rows)
}
