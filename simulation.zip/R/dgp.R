# DGPs from the uploaded scripts, locally scoped to avoid name collisions.
# Study 1 Case 1 and Study 3/4 DGP bodies are copied unchanged.
# Study 1 Case 2 and Study 2 Cases 1/2 are adaptations following Appendix C; see README.

get_g_case <- function(i, eps_log = 1e-6) {

  idx <- ((i - 1) %% 15) + 1

  g <- switch(
    idx,
    function(u) (u - 1)^2,
    function(u) u + u^3,
    function(u) exp(-2 * u^2),
    function(u) sin(pi * (u - 1) / 2),
    function(u) log(u^2 + eps_log),
    function(u) exp(-u),
    function(u) cos(pi * (u - 1) / 2),
    function(u) (u + 1)^2,
    function(u) log(u^2 + 1),
    function(u) u,
    function(u) exp(-u) + 1,
    function(u) sin(pi * (u - 1) / 3),
    function(u) cos(pi * (u - 1) / 3),
    function(u) u^2,
    function(u) (u - 1)^2+1
  )

  gp <- switch(
    idx,
    function(u) 2 * (u - 1),
    function(u) 1 + 3 * u^2,
    function(u) -4 * u * exp(-2 * u^2),
    function(u) (pi / 2) * cos(pi * (u - 1) / 2),
    function(u) 2 * u / (u^2 + eps_log),
    function(u) -exp(-u),
    function(u) -(pi / 2) * sin(pi * (u - 1) / 2),
    function(u) 2 * (u + 1),
    function(u) 2 * u / (u^2 + 1),
    function(u) 1,
    function(u) -exp(-u),
    function(u) (pi / 3) * cos(pi * (u - 1) / 3),
    function(u) -(pi / 3) * sin(pi * (u - 1) / 3),
    function(u) 2 * u,
    function(u) 2 * (u - 1)
  )

  list(g = g, gp = gp)
}

original_study1_case1 <- function(N, T, theta_true, beta_true) {

  p1 <- length(theta_true)
  p2 <- length(beta_true)

  X <- array(
    runif(N * T * p1),
    c(N, T, p1)
  )

  Z <- array(
    runif(
      N * T * p2,
      min = -1,
      max = 1
    ),
    c(N, T, p2)
  )

  e <- 0.1 *
    matrix(
      rnorm(N * T),
      N,
      T
    )

  Y <- matrix(
    0,
    N,
    T
  )

  g_list <- vector(
    "list",
    N
  )

  gp_list <- vector(
    "list",
    N
  )

  for (i in 1:N) {

    fun <- get_g_case(i)

    g_list[[i]] <- fun$g
    gp_list[[i]] <- fun$gp

    for (t in 1:T) {

      eta <- sum(
        as.numeric(X[i, t, ]) *
          theta_true
      )

      Y[i, t] <-
        fun$g(eta) +
        sum(
          as.numeric(Z[i, t, ]) *
            beta_true
        ) +
        e[i, t]
    }
  }

  list(
    X = X,
    Z = Z,
    Y = Y,
    e = e,
    g_list = g_list,
    gp_list = gp_list,
    X_types = rep(
      "continuous",
      p1
    ),
    Z_types = rep(
      "continuous",
      p2
    )
  )
}

get_g_study2 <- function(i, eps_log = 1e-6) {
  idx <- ((i - 1L) %% 15L) + 1L
  # Study 2 changes link 5 to log(u^2+1), link 9 to sin(pi*(u-1)/4).
  if (idx == 5L) return(list(g = function(u) log(u^2 + 1),
                             gp = function(u) 2*u/(u^2+1)))
  if (idx == 9L) return(list(g = function(u) sin(pi*(u-1)/4),
                             gp = function(u) (pi/4)*cos(pi*(u-1)/4)))
  get_g_case(i, eps_log = eps_log)
}

generate_study12 <- function(N, T, theta_true, beta_true, study, case) {
  stopifnot(study %in% c(1L, 2L), case %in% c(1L, 2L))
  if (study == 1L && case == 1L)
    return(original_study1_case1(N, T, theta_true, beta_true))
  p <- length(theta_true); d <- length(beta_true)
  X <- if (study == 1L) array(runif(N*T*p), c(N,T,p))
       else array(rbinom(N*T*p, 1L, 0.5), c(N,T,p))
  Z <- if (case == 2L) array(rbinom(N*T*d, 1L, 0.5), c(N,T,d))
       else if (study == 1L) array(runif(N*T*d,min=-1,max=1), c(N,T,d))
       else array(rexp(N*T*d,rate=0.5), c(N,T,d))
  e <- 0.1*matrix(rnorm(N*T),N,T)
  Y <- matrix(0,N,T)
  g_list <- gp_list <- vector("list",N)
  for (i in seq_len(N)) {
    gi <- if (study == 1L) get_g_case(i) else get_g_study2(i)
    g_list[[i]] <- gi$g; gp_list[[i]] <- gi$gp
    for (t in seq_len(T)) {
      u <- sum(theta_true * as.numeric(X[i,t,]))
      Y[i,t] <- gi$g(u)+sum(beta_true*as.numeric(Z[i,t,]))+e[i,t]
    }
  }
  list(X=X,Z=Z,Y=Y,e=e,g_list=g_list,gp_list=gp_list,
       X_types=rep(if(study==1L) "continuous" else "binary",p),
       Z_types=rep(if(case==2L) "binary" else "continuous",d))
}

generate_study3_case1 <- function(N, T, theta_true, beta_true, lambda = NULL) {
  eta_fun <- function(u) {
    sin(pi * (u - A_CHEN) / (B_CHEN - A_CHEN))
  }

  eta_prime <- function(u) {
    (pi / (B_CHEN - A_CHEN)) *
      cos(pi * (u - A_CHEN) / (B_CHEN - A_CHEN))
  }

  generator <- function(N, T, theta_true, beta_true) {
    p1 <- length(theta_true)
    p2 <- length(beta_true)
    stopifnot(p1 == 3L, p2 == 1L)

    # X components are independent U(0,1), iid over i and t.
    X <- array(
      runif(N * T * p1),
      c(N, T, p1)
    )

    # Z_it is deterministic in t: 0 for odd t, 1 for even t.
    z_time <- as.numeric(seq_len(T) %% 2L == 0L)
    Zmat <- matrix(
      rep(z_time, each = N),
      nrow = N,
      ncol = T
    )
    Z <- array(0, c(N, T, 1L))
    Z[, , 1] <- Zmat

    # Chen fixed effects.
    Z_iA_star <- rowMeans(Zmat)
    alpha <- numeric(N)

    if (N > 1L) {
      u <- rnorm(N - 1L, mean = 0, sd = 0.1)
      alpha[seq_len(N - 1L)] <-
        0.5 * Z_iA_star[seq_len(N - 1L)] + u
      alpha[N] <- -sum(alpha[seq_len(N - 1L)])
    }

    # Idiosyncratic errors v_it iid N(0,0.1^2).
    v <- matrix(
      rnorm(N * T, mean = 0, sd = 0.1),
      N,
      T
    )

    Y <- matrix(NA_real_, N, T)
    g_list <- vector("list", N)
    gp_list <- vector("list", N)

    for (i in seq_len(N)) {
      ai <- alpha[i]

      g_list[[i]] <- local({
        a0 <- ai
        function(u) eta_fun(u) + a0
      })

      gp_list[[i]] <- eta_prime

      for (t in seq_len(T)) {
        index_true <- sum(theta_true * as.numeric(X[i, t, ]))

        Y[i, t] <-
          sum(beta_true * as.numeric(Z[i, t, ])) +
          eta_fun(index_true) +
          alpha[i] +
          v[i, t]
      }
    }

    stopifnot(abs(sum(alpha)) < 1e-10)

    list(
      X = X,
      Z = Z,
      Y = Y,
      e = v,
      v = v,
      alpha = alpha,
      g_list = g_list,
      gp_list = gp_list,
      X_types = rep("continuous", p1),
      Z_types = rep("binary", p2)
    )
  }
  A_CHEN <- 0.3912; B_CHEN <- 1.3409
    generator(N, T, theta_true, beta_true)
}

generate_study3_case2 <- function(N, T, theta_true, beta_true, lambda = NULL) {
  eta_fun <- function(u) {
    2 * exp(-3 * u^2)
  }

  eta_prime <- function(u) {
    -12 * u * exp(-3 * u^2)
  }

  generate_X_lag_array <- function(N, T, burn_in = AR_BURN_IN) {
    X <- array(NA_real_, c(N, T, 3L))

    for (i in seq_len(N)) {
      total_needed <- burn_in + T + 2L
      x_scalar <- numeric(total_needed)

      # x_scalar[1] = 0 only starts the discarded burn-in segment.
      for (s in 2:total_needed) {
        innovation <- runif(1, min = -1, max = 1)
        x_scalar[s] <- 0.4 * x_scalar[s - 1L] + innovation
      }

      keep <- x_scalar[(burn_in + 1L):(burn_in + T + 2L)]

      for (t in seq_len(T)) {
        # Regressor vector = (X_it, X_i,t-1, X_i,t-2)'.
        X[i, t, ] <- c(
          keep[t + 2L],
          keep[t + 1L],
          keep[t]
        )
      }
    }

    X
  }

  generator <- function(N, T, theta_true, beta_true) {
    p1 <- length(theta_true)
    p2 <- length(beta_true)
    stopifnot(p1 == 3L, p2 == 2L)

    # Generate AR(1) scalar X and form lag vector.
    X <- generate_X_lag_array(N, T)

    # Z has two independent Bernoulli(0.5) components, iid over i,t.
    Z <- array(
      rbinom(N * T * p2, size = 1, prob = 0.5),
      c(N, T, p2)
    )

    # Chen fixed effects.
    Z_iA_star <- rowMeans((Z[, , 1] + Z[, , 2]) / 2)
    alpha <- numeric(N)

    if (N > 1L) {
      u <- rnorm(N - 1L, mean = 0, sd = 0.2)
      alpha[seq_len(N - 1L)] <-
        0.5 * Z_iA_star[seq_len(N - 1L)] + u
      alpha[N] <- -sum(alpha[seq_len(N - 1L)])
    }

    # Idiosyncratic errors v_it iid N(0,0.5^2).
    v <- matrix(
      rnorm(N * T, mean = 0, sd = 0.5),
      N,
      T
    )

    Y <- matrix(NA_real_, N, T)
    g_list <- vector("list", N)
    gp_list <- vector("list", N)

    for (i in seq_len(N)) {
      ai <- alpha[i]

      g_list[[i]] <- local({
        a0 <- ai
        function(u) eta_fun(u) + a0
      })

      gp_list[[i]] <- eta_prime

      for (t in seq_len(T)) {
        index_true <- sum(theta_true * as.numeric(X[i, t, ]))

        Y[i, t] <-
          sum(beta_true * as.numeric(Z[i, t, ])) +
          eta_fun(index_true) +
          alpha[i] +
          v[i, t]
      }
    }

    stopifnot(abs(sum(alpha)) < 1e-10)

    list(
      X = X,
      Z = Z,
      Y = Y,
      e = v,
      v = v,
      alpha = alpha,
      g_list = g_list,
      gp_list = gp_list,
      X_types = rep("continuous", p1),
      Z_types = rep("binary", p2)
    )
  }
  AR_BURN_IN <- 500L
    generator(N, T, theta_true, beta_true)
}

generate_study4_case1 <- function(N, T, theta_true, beta_true, lambda = NULL) {
  g_base <- function(u) {
    sin(pi * (u - 1) / 2) + 0.5 * u^2
  }

  gp_base <- function(u) {
    (pi / 2) * cos(pi * (u - 1) / 2) + u
  }

  standardised_scores <- function(N) {
    x <- sin(2 * pi * (1:N) / max(N, 2))
    x <- x - mean(x)
    sx <- sd(x)
    if (!is.finite(sx) || sx < 1e-10) {
      x <- seq(-1, 1, length.out = N)
      x <- x - mean(x)
      sx <- sd(x)
    }
    x / sx
  }

  generator_factory <- function(lambda) {
    force(lambda)
    function(N, T, theta_true, beta_true) {
      p1 <- length(theta_true); p2 <- length(beta_true)
      X <- array(runif(N * T * p1), c(N, T, p1))
      Z <- array(runif(N * T * p2, min = -1, max = 1), c(N, T, p2))
      e <- 0.1 * matrix(rnorm(N * T), N, T)
      Y <- matrix(0, N, T)
      alpha_scale <- 0.30
      alpha <- alpha_scale * lambda * standardised_scores(N)
      g_list <- vector("list", N); gp_list <- vector("list", N)
      for (i in 1:N) {
        ai <- alpha[i]
        g_list[[i]] <- local({ a0 <- ai; function(u) g_base(u) + a0 })
        gp_list[[i]] <- function(u) gp_base(u)
        for (t in 1:T) {
          eta <- sum(as.numeric(X[i, t, ]) * theta_true)
          Y[i, t] <- g_list[[i]](eta) +
            sum(as.numeric(Z[i, t, ]) * beta_true) + e[i, t]
        }
      }
      list(X = X, Z = Z, Y = Y, e = e,
           g_list = g_list, gp_list = gp_list,
           X_types = rep("continuous", p1), Z_types = rep("continuous", p2),
           alpha = alpha, lambda = lambda)
    }
  }
  if (is.null(lambda)) lambda <- 0.5
    generator_factory(lambda)(N, T, theta_true, beta_true)
}

generate_study4_case2 <- function(N, T, theta_true, beta_true, lambda = NULL) {
  g_base <- function(u) {
    sin(pi * (u - 1) / 2) + 0.5 * u^2
  }

  gp_base <- function(u) {
    (pi / 2) * cos(pi * (u - 1) / 2) + u
  }

  q_shape <- function(u) sin(pi * u)

  qp_shape <- function(u) pi * cos(pi * u)

  standardised_scores <- function(N, phase = 0) {
    x <- sin(2 * pi * (1:N + phase) / max(N, 2))
    x <- x - mean(x)
    sx <- sd(x)
    if (!is.finite(sx) || sx < 1e-10) {
      x <- seq(-1, 1, length.out = N)
      x <- x - mean(x)
      sx <- sd(x)
    }
    x / sx
  }

  generator_factory <- function(lambda) {
    force(lambda)
    function(N, T, theta_true, beta_true) {
      p1 <- length(theta_true); p2 <- length(beta_true)
      X <- array(runif(N * T * p1), c(N, T, p1))
      Z <- array(runif(N * T * p2, min = -1, max = 1), c(N, T, p2))
      e <- 0.1 * matrix(rnorm(N * T), N, T)
      Y <- matrix(0, N, T)
      alpha_scale <- 0.30; shape_scale <- 0.30
      alpha <- alpha_scale * standardised_scores(N, phase = 0)
      shape <- shape_scale * lambda * standardised_scores(N, phase = 0.37)
      g_list <- vector("list", N); gp_list <- vector("list", N)
      for (i in 1:N) {
        ai <- alpha[i]; si <- shape[i]
        g_list[[i]] <- local({
          a0 <- ai; s0 <- si
          function(u) g_base(u) + a0 + s0 * q_shape(u)
        })
        gp_list[[i]] <- local({
          s0 <- si
          function(u) gp_base(u) + s0 * qp_shape(u)
        })
        for (t in 1:T) {
          eta <- sum(as.numeric(X[i, t, ]) * theta_true)
          Y[i, t] <- g_list[[i]](eta) +
            sum(as.numeric(Z[i, t, ]) * beta_true) + e[i, t]
        }
      }
      list(X = X, Z = Z, Y = Y, e = e,
           g_list = g_list, gp_list = gp_list,
           X_types = rep("continuous", p1), Z_types = rep("continuous", p2),
           alpha = alpha, shape = shape, lambda = lambda)
    }
  }
  if (is.null(lambda)) lambda <- 0.25
    generator_factory(lambda)(N, T, theta_true, beta_true)
}
