# Study 5 Case 1: intentional reallocation of Z columns into X for Mth1.
# Original DGP stays unchanged. Mth1, Mth2, ADE, CV and kernels are
# shared with all other study scripts; no copied estimator implementation.

misallocation_order <- function(d, seed) {
  set.seed(seed)
  sample.int(d, size=d, replace=FALSE)
}

misallocation_view <- function(dat, moved) {
  N <- dim(dat$X)[1]; Tt <- dim(dat$X)[2]
  p <- dim(dat$X)[3]; d <- dim(dat$Z)[3]
  moved <- sort(unique(as.integer(moved)))
  keep <- setdiff(seq_len(d), moved)
  stopifnot(length(keep) >= 1L)
  Xnew <- array(0, c(N,Tt,p+length(moved)))
  Xnew[,,seq_len(p)] <- dat$X
  for (j in seq_along(moved)) Xnew[,,p+j] <- dat$Z[,,moved[j]]
  list(X=Xnew, Z=dat$Z[,,keep,drop=FALSE], Y=dat$Y,
       moved=moved, keep=keep)
}

misallocation_effects_mth1 <- function(dat, view, fit, theta_true,
                                        beta_true, h) {
  N <- dim(dat$X)[1]; Tt <- dim(dat$X)[2]
  p <- dim(dat$X)[3]; d <- dim(dat$Z)[3]
  ne <- N*Tt
  total_true <- total_est <- total_sq <- numeric(p+d)
  moved <- view$moved; keep <- view$keep
  for (i in seq_len(N)) for (t in seq_len(Tt)) {
    x <- as.numeric(dat$X[i,t,]); z <- as.numeric(dat$Z[i,t,])
    u_true <- sum(theta_true*x)
    u_fit <- sum(fit$theta*as.numeric(view$X[i,t,]))
    truth <- c(dat$gp_list[[i]](u_true)*theta_true, beta_true)
    est <- numeric(p+d)
    est[seq_len(p)] <- fit$b[i,t]*fit$theta[seq_len(p)]
    for (j in seq_len(d)) {
      if (j %in% moved) {
        pos <- p + match(j,moved)
        if (dat$Z_types[j] == "continuous") {
          # Uploaded Study 5 Case 1 code: continuous Z derivative.
          est[p+j] <- fit$b[i,t]*fit$theta[pos]
        } else {
          # Extension for the paper's binary-Z scenario: 0-to-1 change.
          u0 <- u_fit - fit$theta[pos]*z[j]
          est[p+j] <- estimate_g_method1_at(i,u0+fit$theta[pos],
                         fit,view$X,view$Z,view$Y,h) -
                      estimate_g_method1_at(i,u0,
                         fit,view$X,view$Z,view$Y,h)
        }
      } else {
        est[p+j] <- fit$beta[match(j,keep)]
      }
    }
    total_true <- total_true + truth
    total_est <- total_est + est
    total_sq <- total_sq + (est-truth)^2
  }
  data.frame(variable=c(paste0("X",seq_len(p)),paste0("Z",seq_len(d))),
             variable_type=c(dat$X_types,dat$Z_types),
             effect_type=c(rep("continuous_derivative",p),
                           vapply(seq_len(d),function(j) {
                             if (j %in% moved && dat$Z_types[j]=="binary")
                               "moved_binary_0_to_1"
                             else if (j %in% moved) "moved_continuous_derivative"
                             else if (dat$Z_types[j]=="binary") "linear_binary_0_to_1"
                             else "linear_continuous_derivative"
                           },character(1))),
             true_avg=total_true/ne,est_avg=total_est/ne,
             point_mse=total_sq/ne,stringsAsFactors=FALSE)
}
