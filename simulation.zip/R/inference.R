# Only inference functions used in Study 5 Case 3; originally source12/02_COEF_CI.R and 03_LINK_CI.R.
# IID plug-in coefficient intervals and pointwise link intervals; do not claim HAC robustness.

ci_unit <- function(X,Z,Y,i) {
  tt <- ncol(Y)
  list(X=matrix(X[i,,],tt,dim(X)[3]),Z=matrix(Z[i,,],tt,dim(Z)[3]))
}

ci_nuisance <- function(X,Z,Y,fit,K,inverse) {
  tt <- ncol(Y); n <- nrow(Y)
  lapply(seq_len(n),function(i) {
    d <- ci_unit(X,Z,Y,i)
    u <- drop(d$X %*% fit$theta)
    y <- Y[i,]-drop(d$Z %*% fit$beta)
    S <- D <- matrix(0,tt,tt)
    for(j in seq_len(tt)) {
      delta <- u-u[j]; L <- cbind(1,delta)
      w <- K(delta/fit$h[i])/fit$h[i]
      # Same local-linear Gram inverse (including its ridge) as the source fit.
      M <- inverse(crossprod(L,L*w)) %*% t(L*w)
      S[j,] <- M[1,]; D[j,] <- M[2,]
    }
    residual <- y-drop(S%*%y)
    df <- sum((diag(tt)-S)^2)
    if(!is.finite(df)||df<=1) stop("Insufficient residual degrees of freedom")
    sigma2 <- sum(residual^2)/df
    if(!is.finite(sigma2)||sigma2<=0) stop("Invalid estimated residual variance")
    list(X=d$X,Z=d$Z,u=u,y=y,S=S,gprime=drop(D%*%y),
         Xbar=S%*%d$X,Zbar=S%*%d$Z,sigma2=sigma2,residual_df=df)
  })
}

ci_parameters <- function(X,Z,Y,fit,nu,level) {
  p <- length(fit$theta); d <- length(fit$beta); m <- length(Y)
  H <- qr.Q(qr(matrix(fit$theta/sqrt(sum(fit$theta^2)),ncol=1)),complete=TRUE)[,-1,drop=FALSE]
  G <- W <- matrix(0,d+p-1L,d+p-1L)
  for(v in nu) {
    Q <- cbind(v$Z-v$Zbar,((v$X-v$Xbar)%*%H)*v$gprime)
    gram <- crossprod(Q)/m
    G <- G+gram; W <- W+v$sigma2*gram
  }
  ev <- eigen(G,symmetric=TRUE,only.values=TRUE)$values
  if(any(!is.finite(ev))||min(ev)<=max(ev)*1e-10) stop("Ill-conditioned parameter covariance bread")
  B <- solve(G)
  J <- matrix(0,d+p,d+p-1L)
  J[seq_len(d),seq_len(d)] <- diag(d)
  J[d+seq_len(p),d+seq_len(p-1L)] <- H
  V <- J%*%B%*%W%*%t(B)%*%t(J)/m
  order <- c(d+seq_len(p),seq_len(d))
  V <- V[order,order,drop=FALSE]
  estimate <- c(fit$theta,fit$beta)
  se <- sqrt(pmax(diag(V),0)); z <- qnorm((1+level)/2)
  list(rows=data.frame(parameter=c(paste0("theta",seq_len(p)),paste0("beta",seq_len(d))),
    estimate=estimate,se=se,lower=estimate-z*se,upper=estimate+z*se,
    valid=is.finite(se)&se>0),covariance=V,bread_condition=max(ev)/min(ev))
}

ci_get_g <- function(i, eps_log = 1e-6) {
  idx <- as.integer(((i - 1L) %% 15L) + 1L)

  g <- switch(
    idx,
    function(u) (u - 1)^2,
    function(u) u + u^3,
    function(u) exp(-2 * u^2),
    function(u) sin(pi * (u - 1) / 2),
    function(u) log(u^2 + eps_log),
    function(u) exp(-u),
    function(u) cos(pi * (u - 1) / 2),
    function(u) (u + 1)^2,
    function(u) log(u^2 + 1),
    function(u) u,
    function(u) exp(-u) + 1,
    function(u) sin(pi * (u - 1) / 3),
    function(u) cos(pi * (u - 1) / 3),
    function(u) u^2,
    function(u) (u - 1)^2 + 1
  )

  # TRUE second derivative: used ONLY for the oracle simulation diagnostic.
  gpp <- switch(
    idx,
    function(u) 2 + 0 * u,
    function(u) 6 * u,
    function(u) (-4 + 16 * u^2) * exp(-2 * u^2),
    function(u) -(pi^2 / 4) * sin(pi * (u - 1) / 2),
    function(u) 2 * (eps_log - u^2) / (u^2 + eps_log)^2,
    function(u) exp(-u),
    function(u) -(pi^2 / 4) * cos(pi * (u - 1) / 2),
    function(u) 2 + 0 * u,
    function(u) 2 * (1 - u^2) / (u^2 + 1)^2,
    function(u) 0 * u,
    function(u) exp(-u),
    function(u) -(pi^2 / 9) * sin(pi * (u - 1) / 3),
    function(u) -(pi^2 / 9) * cos(pi * (u - 1) / 3),
    function(u) 2 + 0 * u,
    function(u) 2 + 0 * u
  )

  list(g = g, gpp = gpp, idx = idx)
}

ci_kernel <- function(x) {
  vapply(as.numeric(x), function(z) as.numeric(K1(z)), numeric(1))
}

ci_kernel_constants <- function() {
  R_K <- integrate(
    function(u) ci_kernel(u)^2,
    lower = -10, upper = 10,
    subdivisions = 500L, rel.tol = 1e-8
  )$value
  mu2 <- integrate(
    function(u) u^2 * ci_kernel(u),
    lower = -10, upper = 10,
    subdivisions = 500L, rel.tol = 1e-8
  )$value
  mass <- integrate(
    function(u) ci_kernel(u),
    lower = -10, upper = 10,
    subdivisions = 500L, rel.tol = 1e-8
  )$value
  list(R_K = R_K, mu2 = mu2, mass = mass)
}

ci_index_support <- function(theta_true) {
  c(
    lower = sum(pmin(theta_true, 0)),
    upper = sum(pmax(theta_true, 0))
  )
}

ci_make_grid <- function(theta_true, n = 41L) {
  sp <- ci_index_support(theta_true)
  seq(sp["lower"], sp["upper"], length.out = n)
}

ci_is_interior <- function(u, theta_true, trim = 0.10) {
  sp <- ci_index_support(theta_true)
  w <- sp["upper"] - sp["lower"]
  u >= sp["lower"] + trim * w & u <= sp["upper"] - trim * w
}

ci_x_from_true_u <- function(u, theta_true) {
  # Current Study 1 theta_true has positive equal coordinates.
  x0 <- rep(u / sum(theta_true), length(theta_true))
  pmin(pmax(x0, 0), 1)
}

ci_safe_ginv <- function(A, ridge = 1e-8) {
  solve(A + ridge * diag(nrow(A)))
}

ci_local_linear <- function(eta, y, u0, h) {
  n <- length(eta)
  d <- eta - u0
  w <- ci_kernel(d / h) / h
  ok <- is.finite(d) & is.finite(y) & is.finite(w) & w >= 0

  out_bad <- function() {
    list(
      ghat = NA_real_, ell = rep(NA_real_, n),
      fhat = NA_real_, var_factor = NA_real_, n_used = sum(ok)
    )
  }

  if (sum(ok) < 3L || sum(w[ok]) <= 0) return(out_bad())

  dd <- d[ok]; yy <- y[ok]; ww <- w[ok]
  S0 <- sum(ww)
  S1 <- sum(ww * dd)
  S2 <- sum(ww * dd^2)
  den <- S0 * S2 - S1^2
  if (!is.finite(den) || abs(den) < 1e-12) return(out_bad())

  T0 <- sum(ww * yy)
  T1 <- sum(ww * dd * yy)
  ghat <- (S2 * T0 - S1 * T1) / den

  ell_use <- ww * (S2 - S1 * dd) / den
  ell <- rep(0, n)
  ell[which(ok)] <- ell_use

  list(
    ghat = ghat,
    ell = ell,
    fhat = mean(w[is.finite(w)]),
    var_factor = sum(ell_use^2),
    n_used = length(ell_use)
  )
}

ci_local_quadratic_gpp <- function(eta, y, u0, h_bias) {
  d <- eta - u0
  w <- ci_kernel(d / h_bias) / h_bias
  ok <- is.finite(d) & is.finite(y) & is.finite(w) & w >= 0
  d <- d[ok]; y <- y[ok]; w <- w[ok]

  if (length(y) < 5L || sum(w) <= 0) return(NA_real_)

  Q <- cbind(1, d, d^2)
  A <- crossprod(Q, Q * w)
  b <- crossprod(Q, w * y)
  co <- tryCatch(
    as.numeric(ci_safe_ginv(A, ridge = 1e-8) %*% b),
    error = function(e) rep(NA_real_, 3L)
  )
  if (length(co) < 3L || !is.finite(co[3])) return(NA_real_)

  # a + b*d + c*d^2 => g''(u0) ~= 2c.
  2 * co[3]
}

ci_station_diagnostics <- function(dat, fit, i, h) {
  Tt <- dim(dat$X)[2]
  eta <- numeric(Tt)
  y_partial <- numeric(Tt)

  for (t in seq_len(Tt)) {
    eta[t] <- sum(fit$theta * as.numeric(dat$X[i, t, ]))
    y_partial[t] <- dat$Y[i, t] -
      sum(fit$beta * as.numeric(dat$Z[i, t, ]))
  }

  S <- matrix(NA_real_, Tt, Tt)
  valid <- rep(FALSE, Tt)
  for (s in seq_len(Tt)) {
    ll <- ci_local_linear(eta, y_partial, eta[s], h)
    if (length(ll$ell) == Tt && all(is.finite(ll$ell))) {
      S[s, ] <- ll$ell
      valid[s] <- TRUE
    }
  }

  if (all(valid)) {
    fitted <- as.numeric(S %*% y_partial)
    residual <- y_partial - fitted
    RSS <- sum(residual^2)
    trS <- sum(diag(S))
    trStS <- sum(S^2)
    df_resid <- Tt - 2 * trS + trStS
    sigma2_df <- if (is.finite(df_resid) && df_resid > 1e-8) {
      RSS / df_resid
    } else {
      RSS / Tt
    }
  } else {
    # Fallback only when a smoothing row is numerically unavailable.
    fitted <- as.numeric(fit$a[i, ])
    residual <- y_partial - fitted
    RSS <- sum(residual^2, na.rm = TRUE)
    sigma2_df <- mean(residual^2, na.rm = TRUE)
    trS <- NA_real_; trStS <- NA_real_; df_resid <- NA_real_
  }

  list(
    eta = eta,
    y_partial = y_partial,
    sigma2 = sigma2_df,
    RSS = RSS,
    df_resid = df_resid,
    trS = trS,
    trStS = trStS
  )
}

ci_eval_station <- function(
    dat, fit, i, theta_true, h, u_grid, kernel_const,
    bias_bw_mult = 1.50, ci_level = 0.95, interior_trim = 0.10,
    primary_se = c("equivalent", "theorem")
) {
  primary_se <- match.arg(primary_se)
  Tt <- dim(dat$X)[2]
  zcrit <- qnorm(1 - (1 - ci_level) / 2)
  diag_i <- ci_station_diagnostics(dat, fit, i, h)

  ans <- vector("list", length(u_grid))
  for (j in seq_along(u_grid)) {
    u_true <- u_grid[j]
    x0 <- ci_x_from_true_u(u_true, theta_true)
    u_hat <- sum(fit$theta * x0)

    ll <- ci_local_linear(diag_i$eta, diag_i$y_partial, u_hat, h)
    g_true <- dat$g_list[[i]](u_true)

    # TRUE g'' is available only because this is a Monte Carlo experiment.
    # It is used ONLY in the oracle diagnostic.
    gpp_true <- dat$gpp_list[[i]](u_true)
    bias_oracle <- 0.5 * kernel_const$mu2 * h^2 * gpp_true

    # FEASIBLE g'' is estimated exactly as it would be in a real application.
    h_bias <- bias_bw_mult * h
    gpp_hat <- ci_local_quadratic_gpp(
      diag_i$eta, diag_i$y_partial, u_hat,
      h_bias = h_bias
    )
    bias_hat <- if (is.finite(gpp_hat)) {
      0.5 * kernel_const$mu2 * h^2 * gpp_hat
    } else {
      NA_real_
    }

    center_raw <- ll$ghat
    center_oracle <- if (is.finite(center_raw) && is.finite(bias_oracle)) {
      center_raw - bias_oracle
    } else NA_real_
    center_feasible <- if (is.finite(center_raw) && is.finite(bias_hat)) {
      center_raw - bias_hat
    } else NA_real_

    se_eq <- if (
      is.finite(diag_i$sigma2) && diag_i$sigma2 >= 0 &&
      is.finite(ll$var_factor) && ll$var_factor > 0
    ) sqrt(diag_i$sigma2 * ll$var_factor) else NA_real_

    se_theory <- if (
      is.finite(diag_i$sigma2) && diag_i$sigma2 >= 0 &&
      is.finite(ll$fhat) && ll$fhat > 1e-10
    ) sqrt(diag_i$sigma2 * kernel_const$R_K / (Tt * h * ll$fhat)) else NA_real_

    se <- if (primary_se == "equivalent") se_eq else se_theory

    lo_raw <- center_raw - zcrit * se
    hi_raw <- center_raw + zcrit * se
    lo_oracle <- center_oracle - zcrit * se
    hi_oracle <- center_oracle + zcrit * se
    lo_feasible <- center_feasible - zcrit * se
    hi_feasible <- center_feasible + zcrit * se

    valid_interval <- function(g, lo, hi) all(is.finite(c(g, lo, hi)))
    cover <- function(g, lo, hi) {
      if (valid_interval(g, lo, hi)) g >= lo && g <= hi else NA
    }

    ans[[j]] <- data.frame(
      station = i,
      g_id = dat$g_id[i],
      grid_id = j,
      u_true = u_true,
      u_hat = u_hat,
      region = if (ci_is_interior(u_true, theta_true, interior_trim)) "interior" else "boundary",
      h = h,
      h_bias = h_bias,
      g_true = g_true,
      gpp_true = gpp_true,
      g_hat = center_raw,
      gpp_hat = gpp_hat,
      bias_oracle = bias_oracle,
      bias_hat = bias_hat,
      g_hat_oracle = center_oracle,
      g_hat_feasible = center_feasible,
      sigma2_hat = diag_i$sigma2,
      f_hat = ll$fhat,
      se_equivalent = se_eq,
      se_theorem = se_theory,
      se_primary = se,
      lo_raw = lo_raw,
      hi_raw = hi_raw,
      lo_oracle = lo_oracle,
      hi_oracle = hi_oracle,
      lo_feasible = lo_feasible,
      hi_feasible = hi_feasible,
      covered_raw = cover(g_true, lo_raw, hi_raw),
      covered_oracle = cover(g_true, lo_oracle, hi_oracle),
      covered_feasible = cover(g_true, lo_feasible, hi_feasible),
      width = if (all(is.finite(c(se, zcrit)))) 2 * zcrit * se else NA_real_,
      error_raw = center_raw - g_true,
      error_oracle = center_oracle - g_true,
      error_feasible = center_feasible - g_true,
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, ans)
}
