# Source Notes and Scope

The three reference configurations in `README.md` and the R entry scripts are
based on the author's latest explicitly confirmed numbers:

* Study 1 Case 1, N=5, T=20: 200 replications, seed base 15, Mth1 candidate
  grid `seq(0.10,0.35,by=0.05)`, Mth2 grid `seq(0.80,0.90,by=0.05)`.
* Study 3 Case 1, N=10, T=10: 200 replications, seed base 66, Mth1 grid
  `seq(0.10,0.30,by=0.05)`, Chen (2013a) Mth3 grid
  `seq(0.25,0.45,by=0.05)`. 
* Study 5 Case 1, N=10, T=30, k=1: seed base 10000, Mth1 grid
  `seq(0.15,0.45,by=0.05)`. 200 replications.


Studies 1 and 2 share Mth1/Mth2 estimation routines and differ in their DGP
and link definitions. Studies 3 and 4 similarly share Mth1/Mth3 but differ in
their DGPs. Study 5 provides one continuous-Z reallocation example plus
standalone calculations for three-stage efficiency and pointwise confidence
intervals. 
